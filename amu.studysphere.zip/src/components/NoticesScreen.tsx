import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Tabs, TabsList, TabsTrigger } from "./ui/tabs";
import { LanguageSelector } from "./LanguageSelector";
import { AudioPlayer } from "./AudioPlayer";
import { useLanguage } from "./LanguageContext";
import { Megaphone, Calendar, Users, Sparkles, Pin, Volume2 } from "lucide-react";
import { useState } from "react";

export function NoticesScreen() {
  const [activeTab, setActiveTab] = useState("all");
  const [audioPlaying, setAudioPlaying] = useState<{ text: string; title: string } | null>(null);
  const { language, audioEnabled } = useLanguage();

  const noticesData = [
    {
      id: 1,
      title: {
        english: "AMU Techfest 2025 - Registration Open",
        urdu: "اے ایم یو ٹیک فیسٹ 2025 - رجسٹریشن کھلی",
        hindi: "एएमयू टेकफेस्ट 2025 - पंजीकरण खुला"
      },
      category: "Hackathons",
      date: "Oct 5, 2025",
      time: "Posted 2 hours ago",
      description: {
        english: "Join the biggest technical festival! Participate in coding competitions, workshops, and project exhibitions. Prize pool worth ₹5 lakhs.",
        urdu: "سب سے بڑے تکنیکی میلے میں شامل ہوں! کوڈنگ مقابلوں، ورکشاپس، اور پراجیکٹ نمائشوں میں حصہ لیں۔ انعامی رقم 5 لاکھ روپے۔",
        hindi: "सबसे बड़े तकनीकी महोत्सव में शामिल हों! कोडिंग प्रतियोगिताओं, कार्यशालाओं और परियोजना प्रदर्शनियों में भाग लें। ₹5 लाख की पुरस्कार राशि।"
      },
      isPinned: true,
      icon: Users,
      color: "text-purple-600",
      bgColor: "bg-purple-50",
      borderColor: "border-purple-200"
    },
    {
      id: 2,
      title: {
        english: "Mid-Semester Examination Schedule Released",
        urdu: "مڈ سمسٹر امتحان کا شیڈول جاری",
        hindi: "मध्य-सेमेस्टर परीक्षा अनुसूची जारी"
      },
      category: "Academics",
      date: "Oct 15-20, 2025",
      time: "Posted 5 hours ago",
      description: {
        english: "The examination schedule for mid-semester has been published. Check your respective department portals for detailed timetables.",
        urdu: "مڈ سمسٹر کا امتحانی شیڈول شائع کر دیا گیا ہے۔ تفصیلی ٹائم ٹیبل کے لیے اپنے متعلقہ شعبے کے پورٹل کو دیکھیں۔",
        hindi: "मध्य-सेमेस्टर की परीक्षा अनुसूची प्रकाशित की गई है। विस्तृत समय सारणी के लिए अपने संबंधित विभाग के पोर्टल की जांच करें।"
      },
      isPinned: true,
      icon: Calendar,
      color: "text-primary",
      bgColor: "bg-primary/5",
      borderColor: "border-primary/20"
    },
    {
      id: 3,
      title: {
        english: "Photography Club - Campus Walk Event",
        urdu: "فوٹوگرافی کلب - کیمپس واک ایونٹ",
        hindi: "फोटोग्राफी क्लब - कैंपस वॉक इवेंट"
      },
      category: "Clubs",
      date: "Oct 3, 2025",
      time: "Posted 1 day ago",
      description: {
        english: "Join us for a guided photography walk around AMU campus. Learn techniques and capture the beauty of our historic architecture.",
        urdu: "اے ایم یو کیمپس میں رہنمائی شدہ فوٹوگرافی واک کے لیے ہمارے ساتھ شامل ہوں۔ تکنیک سیکھیں اور ہماری تاریخی فن تعمیر کی خوبصورتی کو قید کریں۔",
        hindi: "एएमयू कैंपस में एक निर्देशित फोटोग्राफी वॉक के लिए हमसे जुड़ें। तकनीक सीखें और हमारी ऐतिहासिक वास्तुकला की सुंदरता को कैद करें।"
      },
      isPinned: false,
      icon: Users,
      color: "text-accent",
      bgColor: "bg-accent/10",
      borderColor: "border-accent/30"
    },
    {
      id: 4,
      title: {
        english: "Guest Lecture: AI in Healthcare",
        urdu: "مہمان لیکچر: صحت کی دیکھ بھال میں اے آئی",
        hindi: "अतिथि व्याख्यान: स्वास्थ्य सेवा में AI"
      },
      category: "Academics",
      date: "Oct 6, 2025",
      time: "Posted 2 days ago",
      description: {
        english: "Dr. Sarah Ahmed from IIT Delhi will deliver a lecture on applications of Artificial Intelligence in modern healthcare systems.",
        urdu: "آئی آئی ٹی دہلی سے ڈاکٹر سارہ احمد جدید صحت کی دیکھ بھال کے نظام میں مصنوعی ذہانت کے استعمال پر لیکچر دیں گی۔",
        hindi: "IIT दिल्ली से डॉ. सारा अहमद आधुनिक स्वास्थ्य सेवा प्रणालियों में कृत्रिम बुद्धिमत्ता के अनुप्रयोगों पर व्याख्यान देंगी।"
      },
      isPinned: false,
      icon: Megaphone,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
      borderColor: "border-blue-200"
    },
    {
      id: 5,
      title: {
        english: "Coding Competition by GDGC AMU",
        urdu: "جی ڈی جی سی اے ایم یو کا کوڈنگ مقابلہ",
        hindi: "GDGC AMU द्वारा कोडिंग प्रतियोगिता"
      },
      category: "Hackathons",
      date: "Oct 8, 2025",
      time: "Posted 3 days ago",
      description: {
        english: "48-hour online coding hackathon. Form teams of 2-4 members. Top 3 teams win prizes and internship opportunities.",
        urdu: "48 گھنٹے کا آن لائن کوڈنگ ہیکاتھون۔ 2-4 اراکین کی ٹیمیں بنائیں۔ ٹاپ 3 ٹیمیں انعامات اور انٹرنشپ کے مواقع جیتتی ہیں۔",
        hindi: "48 घंटे का ऑनलाइन कोडिंग हैकथॉन। 2-4 सदस्यों की टीमें बनाएं। शीर्ष 3 टीमें पुरस्कार और इंटर्नशिप के अवसर जीतती हैं।"
      },
      isPinned: false,
      icon: Users,
      color: "text-secondary",
      bgColor: "bg-secondary/5",
      borderColor: "border-secondary/20"
    }
  ];

  const handlePlayAudio = (notice: typeof noticesData[0]) => {
    setAudioPlaying({
      title: notice.title[language],
      text: notice.description[language]
    });
  };

  const filteredNotices = activeTab === "all" 
    ? noticesData 
    : noticesData.filter(n => n.category.toLowerCase() === activeTab);

  return (
    <div className="space-y-6">
      {/* Header with Language Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="mb-1">Notices & Events</h2>
          <p className="text-muted-foreground">Stay updated with campus activities</p>
        </div>
        <LanguageSelector />
      </div>

      {/* Filters */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="w-full grid grid-cols-4 h-auto">
          <TabsTrigger value="all" className="text-xs sm:text-sm">All</TabsTrigger>
          <TabsTrigger value="hackathons" className="text-xs sm:text-sm">Hackathons</TabsTrigger>
          <TabsTrigger value="academics" className="text-xs sm:text-sm">Academics</TabsTrigger>
          <TabsTrigger value="clubs" className="text-xs sm:text-sm">Clubs</TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Notices List */}
      <div className="space-y-4">
        {filteredNotices.map((notice) => {
          const Icon = notice.icon;
          return (
            <Card 
              key={notice.id} 
              className={`border ${notice.borderColor} hover:shadow-lg transition-shadow relative overflow-hidden`}
            >
              {notice.isPinned && (
                <div className="absolute top-3 right-3">
                  <Pin className="w-4 h-4 text-primary fill-primary" />
                </div>
              )}
              
              <CardContent className="p-4">
                <div className="flex gap-4">
                  <div className={`${notice.bgColor} ${notice.color} p-3 rounded-lg h-fit`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start gap-2 mb-2">
                      <h4 className="flex-1 line-clamp-1">{notice.title[language]}</h4>
                      {audioEnabled && (
                        <Button 
                          size="sm" 
                          variant="ghost"
                          className="h-7 w-7 p-0 text-blue-600 hover:text-blue-700 hover:bg-blue-50 shrink-0"
                          onClick={() => handlePlayAudio(notice)}
                          title="Play audio"
                        >
                          <Volume2 className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                    
                    <div className="flex flex-wrap items-center gap-2 mb-3 text-muted-foreground">
                      <Badge variant="secondary" className={`${notice.bgColor} ${notice.color} border-0`}>
                        {notice.category}
                      </Badge>
                      <span>•</span>
                      <Calendar className="w-3 h-3" />
                      <span>{notice.date}</span>
                      <span className="hidden sm:inline">•</span>
                      <span className="hidden sm:inline">{notice.time}</span>
                    </div>
                    
                    <p className="text-muted-foreground mb-4 leading-relaxed">
                      {notice.description[language]}
                    </p>
                    
                    <div className="flex items-center gap-2">
                      <Button 
                        size="sm" 
                        variant="outline"
                        className={`${notice.color} border-current`}
                      >
                        Read More
                      </Button>
                      <Button 
                        size="sm" 
                        variant="ghost"
                        className="text-primary hover:text-primary/80"
                        onClick={() => {
                          // Show AI summary
                          alert(`AI Summary: ${notice.title[language]} - Key points include upcoming ${notice.category.toLowerCase()} event on ${notice.date}. Registration/participation encouraged.`);
                        }}
                      >
                        <Sparkles className="w-4 h-4 mr-1" />
                        AI Summarize
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Audio Player */}
      {audioPlaying && (
        <AudioPlayer
          text={audioPlaying.text}
          title={audioPlaying.title}
          language={language}
          onClose={() => setAudioPlaying(null)}
        />
      )}
    </div>
  );
}