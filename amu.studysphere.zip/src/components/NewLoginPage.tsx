import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { ArchPattern, IslamicPattern } from "./IslamicPattern";
import { GraduationCap } from "lucide-react";

interface NewLoginPageProps {
  onLogin: () => void;
}

export function NewLoginPage({ onLogin }: NewLoginPageProps) {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin();
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Islamic Pattern Background */}
      <div className="absolute inset-0 text-primary">
        <IslamicPattern opacity={0.03} />
      </div>

      {/* Arch Header */}
      <div className="relative">
        <ArchPattern className="w-full h-32 text-primary" color="#006838" />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="bg-white rounded-full p-4 shadow-lg">
            <GraduationCap className="w-12 h-12 text-primary" />
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="relative z-10 px-4 py-8 max-w-md mx-auto -mt-8">
        {/* Logo and Title */}
        <div className="text-center mb-8">
          <div className="inline-block">
            <h1 className="text-primary mb-1">amu.studysphere</h1>
            <div className="h-1 bg-gradient-to-r from-primary via-accent to-secondary rounded-full"></div>
          </div>
          <p className="text-muted-foreground mt-3">Aligarh Muslim University</p>
          <p className="text-muted-foreground">Student Collaboration Portal</p>
        </div>

        {/* Login Card */}
        <Card className="border-border shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-primary via-accent to-secondary"></div>
          
          <CardHeader className="text-center pb-4">
            <CardTitle>Welcome</CardTitle>
            <CardDescription>Sign in to access your portal</CardDescription>
          </CardHeader>
          
          <CardContent>
            <Tabs defaultValue="login" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="login">Login</TabsTrigger>
                <TabsTrigger value="signup">Sign Up</TabsTrigger>
              </TabsList>
              
              <TabsContent value="login">
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="space-y-2">
                    <Label htmlFor="enrollment">Enrollment Number</Label>
                    <Input 
                      id="enrollment" 
                      placeholder="Enter enrollment number" 
                      type="text"
                      className="border-border bg-input-background"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password">Password</Label>
                    <Input 
                      id="password" 
                      placeholder="Enter password" 
                      type="password"
                      className="border-border bg-input-background"
                    />
                  </div>
                  <Button 
                    type="submit" 
                    className="w-full bg-primary hover:bg-primary/90 relative overflow-hidden group"
                  >
                    <span className="relative z-10">Login to Portal</span>
                    <div className="absolute inset-0 bg-gradient-to-r from-primary to-secondary opacity-0 group-hover:opacity-100 transition-opacity"></div>
                  </Button>
                </form>
              </TabsContent>
              
              <TabsContent value="signup">
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <Input 
                      id="name" 
                      placeholder="Enter full name" 
                      type="text"
                      className="border-border bg-input-background"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="enrollment-signup">Enrollment Number</Label>
                    <Input 
                      id="enrollment-signup" 
                      placeholder="Enter enrollment number" 
                      type="text"
                      className="border-border bg-input-background"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input 
                      id="email" 
                      placeholder="student@amu.ac.in" 
                      type="email"
                      className="border-border bg-input-background"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password-signup">Password</Label>
                    <Input 
                      id="password-signup" 
                      placeholder="Create password" 
                      type="password"
                      className="border-border bg-input-background"
                    />
                  </div>
                  <Button 
                    type="submit" 
                    className="w-full bg-secondary hover:bg-secondary/90"
                  >
                    Create Account
                  </Button>
                </form>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center mt-6 text-muted-foreground">
          <p>Built with pride for AMU students</p>
        </div>
      </div>
    </div>
  );
}