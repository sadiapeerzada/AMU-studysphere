import { DashboardView } from "./DashboardView";
import { NotesSharing } from "./NotesSharing";
import { Timetable } from "./Timetable";
import { DoubtSolving } from "./DoubtSolving";
import { NoticesScreen } from "./NoticesScreen";
import { ClubsScreen } from "./ClubsScreen";
import { MentorshipScreen } from "./MentorshipScreen";
import { ToDoScreen } from "./ToDoScreen";
import { Profile } from "./Profile";
import { ProfessorDashboard } from "./ProfessorDashboard";
import { Menu } from "lucide-react";
import { Button } from "./ui/button";

interface DashboardProps {
  currentView: string;
  onNavigate: (view: string) => void;
  userRole: "student" | "professor";
  onLogout: () => void;
  onMenuClick: () => void;
}

export function Dashboard({ currentView, onNavigate, userRole, onLogout, onMenuClick }: DashboardProps) {
  const renderView = () => {
    if (userRole === "professor") {
      switch (currentView) {
        case "dashboard":
          return <ProfessorDashboard onNavigate={onNavigate} />;
        case "notes":
          return <NotesSharing />;
        case "timetable":
          return <Timetable />;
        case "announcements":
          return <NoticesScreen />;
        case "profile":
          return <Profile onLogout={onLogout} userRole={userRole} />;
        default:
          return <ProfessorDashboard onNavigate={onNavigate} />;
      }
    }

    // Student views
    switch (currentView) {
      case "dashboard":
        return <DashboardView onNavigate={onNavigate} />;
      case "notes":
        return <NotesSharing />;
      case "timetable":
        return <Timetable />;
      case "doubts":
        return <DoubtSolving />;
      case "announcements":
        return <NoticesScreen />;
      case "clubs":
        return <ClubsScreen />;
      case "mentorship":
        return <MentorshipScreen />;
      case "assignments":
        return <ToDoScreen />;
      case "profile":
        return <Profile onLogout={onLogout} userRole={userRole} />;
      default:
        return <DashboardView onNavigate={onNavigate} />;
    }
  };

  return (
    <div className="h-full bg-gradient-to-br from-background via-primary/5 to-secondary/5">
      {/* Mobile Header */}
      <div className="md:hidden flex items-center justify-between p-4 bg-white border-b border-border sticky top-0 z-10">
        <Button 
          variant="ghost" 
          size="sm"
          onClick={onMenuClick}
          className="p-2"
        >
          <Menu className="w-5 h-5" />
        </Button>
        <h1 className="text-primary">AMU StudySphere</h1>
        <div className="w-9"></div>
      </div>

      {/* Main Content */}
      <div className="p-4 md:p-6 pb-24 md:pb-6">
        {renderView()}
      </div>
    </div>
  );
}
