import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { ScrollArea } from "./ui/scroll-area";
import { IslamicPattern } from "./IslamicPattern";
import { 
  Sparkles, 
  X, 
  Send, 
  Copy, 
  Save, 
  FileText,
  Languages,
  BookOpen,
  HelpCircle,
  Calendar,
  CheckCircle
} from "lucide-react";

interface AIAssistantProps {
  isOpen: boolean;
  onClose: () => void;
  userRole?: "student" | "professor";
  preloadedContext?: string;
}

interface Message {
  id: number;
  type: "user" | "assistant";
  content: string;
  timestamp: Date;
  actions?: boolean;
}

export function AIAssistant({ isOpen, onClose, userRole = "student", preloadedContext }: AIAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      type: "assistant",
      content: "As-salamu alaykum! I'm Sphere Assistant, your personal study companion. How can I help you today?",
      timestamp: new Date(),
      actions: false
    }
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (preloadedContext && messages.length === 1) {
      handleQuickAction("explain", preloadedContext);
    }
  }, [preloadedContext]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const studentActions = [
    { id: "summarize", label: "Summarize Notes", icon: FileText },
    { id: "explain", label: "Explain Simply", icon: HelpCircle },
    { id: "studyplan", label: "Make Study Plan", icon: Calendar },
    { id: "quiz", label: "Generate Quiz", icon: BookOpen }
  ];

  const professorActions = [
    { id: "quiz", label: "Generate Quiz", icon: BookOpen },
    { id: "summarize", label: "Summarize Lecture", icon: FileText },
    { id: "translate", label: "Translate Notes", icon: Languages }
  ];

  const actions = userRole === "professor" ? professorActions : studentActions;

  const simulateAIResponse = (actionType: string, context?: string) => {
    const responses: Record<string, string> = {
      summarize: "📚 Here's a concise summary:\n\n• Key concept 1: Object-oriented programming focuses on creating reusable code through classes and objects\n• Key concept 2: Inheritance allows classes to inherit properties from parent classes\n• Key concept 3: Polymorphism enables objects to take multiple forms\n\nThis reduces complex topics to their essential points for quick review.",
      explain: context 
        ? `Let me explain this in simple terms:\n\n"${context.slice(0, 100)}..."\n\nThink of it like this: Imagine you're organizing a library. Each book (object) has properties like title, author, and pages. The way we organize and access these books is similar to how object-oriented programming works. You group related items together and create rules for how they interact.`
        : "I can explain concepts in simple, everyday language. Just share what you'd like me to clarify!",
      studyplan: "📅 Your Personalized Study Plan:\n\n**Week 1:**\n• Monday-Wednesday: Review OOP concepts (2 hrs/day)\n• Thursday-Friday: Practice coding exercises\n• Weekend: Build a small project\n\n**Week 2:**\n• Monday-Wednesday: Advanced topics\n• Thursday: Revision\n• Friday: Mock test\n\nThis plan balances theory, practice, and rest for optimal learning.",
      quiz: "📝 Practice Quiz Generated:\n\n**Question 1:** What is inheritance in OOP?\nA) Sharing money between classes\nB) A class deriving properties from another class ✓\nC) A type of loop\nD) A database operation\n\n**Question 2:** Which principle allows objects to take multiple forms?\nA) Encapsulation\nB) Abstraction\nC) Polymorphism ✓\nD) Compilation\n\n**Question 3:** What is the main benefit of encapsulation?\nA) Faster code execution\nB) Data hiding and protection ✓\nC) Reduced file size\nD) Better graphics",
      translate: "🌐 Translation to Urdu:\n\nآبجیکٹ اورینٹڈ پروگرامنگ ایک طریقہ ہے جو کوڈ کو دوبارہ استعمال کرنے کے قابل بناتا ہے۔\n\nKey terms:\n• Class - کلاس\n• Object - آبجیکٹ\n• Inheritance - وراثت\n• Polymorphism - کثیر الاشکال\n\nThe translation maintains technical accuracy while being accessible."
    };

    return responses[actionType] || "I'm here to help! Please select an action or type your question.";
  };

  const handleQuickAction = (actionType: string, context?: string) => {
    const actionLabels: Record<string, string> = {
      summarize: "Summarize this content",
      explain: "Explain this in simple words",
      studyplan: "Create a study plan for me",
      quiz: "Generate practice questions",
      translate: "Translate to Urdu"
    };

    const userMessage: Message = {
      id: messages.length + 1,
      type: "user",
      content: context || actionLabels[actionType],
      timestamp: new Date(),
      actions: false
    };

    setMessages(prev => [...prev, userMessage]);
    setIsTyping(true);

    setTimeout(() => {
      const aiMessage: Message = {
        id: messages.length + 2,
        type: "assistant",
        content: simulateAIResponse(actionType, context),
        timestamp: new Date(),
        actions: true
      };
      setMessages(prev => [...prev, aiMessage]);
      setIsTyping(false);
    }, 1500);
  };

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: messages.length + 1,
      type: "user",
      content: input,
      timestamp: new Date(),
      actions: false
    };

    setMessages(prev => [...prev, userMessage]);
    setInput("");
    setIsTyping(true);

    setTimeout(() => {
      const aiMessage: Message = {
        id: messages.length + 2,
        type: "assistant",
        content: "I understand your question. Based on your query, here's what I can help with:\n\nI can provide detailed explanations, break down complex topics, or generate study materials. Would you like me to elaborate on any specific aspect?",
        timestamp: new Date(),
        actions: true
      };
      setMessages(prev => [...prev, aiMessage]);
      setIsTyping(false);
    }, 1500);
  };

  const handleCopy = (content: string) => {
    navigator.clipboard.writeText(content);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center md:justify-end p-4 md:p-6">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/40 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Assistant Panel */}
      <Card className="relative w-full md:w-[440px] h-[85vh] md:h-[600px] flex flex-col shadow-2xl border-primary/20 overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 text-primary pointer-events-none">
          <IslamicPattern opacity={0.02} />
        </div>

        {/* Header */}
        <CardHeader className="border-b border-border bg-gradient-to-r from-primary/5 to-accent/5 relative z-10 p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center shadow-lg animate-pulse">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="mb-0">Sphere Assistant</h3>
                <p className="text-muted-foreground">Your Personal Study Companion</p>
              </div>
            </div>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={onClose}
              className="h-8 w-8 p-0"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
          <div className="mt-3">
            <Badge variant="outline" className="text-xs">
              {userRole === "professor" ? "Professor Mode" : "Student Mode"}
            </Badge>
          </div>
        </CardHeader>

        {/* Messages */}
        <ScrollArea className="flex-1 p-4 relative z-10" ref={scrollRef}>
          <div className="space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.type === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[85%] rounded-lg p-3 ${
                    message.type === "user"
                      ? "bg-primary text-white"
                      : "bg-white border border-border"
                  }`}
                >
                  <p className="whitespace-pre-line leading-relaxed">
                    {message.content}
                  </p>
                  
                  {message.actions && message.type === "assistant" && (
                    <div className="flex items-center gap-2 mt-3 pt-3 border-t border-border">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-7 text-xs"
                        onClick={() => handleCopy(message.content)}
                      >
                        <Copy className="w-3 h-3 mr-1" />
                        Copy
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-7 text-xs"
                      >
                        <Save className="w-3 h-3 mr-1" />
                        Save
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-7 text-xs text-primary"
                      >
                        <FileText className="w-3 h-3 mr-1" />
                        Add to Notes
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            ))}

            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-white border border-border rounded-lg p-3">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                  </div>
                </div>
              </div>
            )}
          </div>
        </ScrollArea>

        {/* Quick Actions */}
        <div className="p-3 border-t border-border bg-muted/30 relative z-10">
          <div className="grid grid-cols-2 gap-2 mb-3">
            {actions.map((action) => {
              const Icon = action.icon;
              return (
                <Button
                  key={action.id}
                  variant="outline"
                  size="sm"
                  className="justify-start text-xs h-8"
                  onClick={() => handleQuickAction(action.id)}
                >
                  <Icon className="w-3 h-3 mr-1" />
                  {action.label}
                </Button>
              );
            })}
          </div>

          {/* Input */}
          <div className="flex gap-2">
            <Input
              placeholder="Type your question..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && handleSend()}
              className="flex-1 border-border bg-white"
            />
            <Button 
              size="sm"
              onClick={handleSend}
              disabled={!input.trim()}
              className="bg-primary hover:bg-primary/90"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}

export function AIAssistantFAB({ onClick }: { onClick: () => void }) {
  return (
    <Button
      onClick={onClick}
      className="fixed bottom-20 md:bottom-6 right-6 w-14 h-14 rounded-full bg-gradient-to-br from-primary to-accent hover:from-primary/90 hover:to-accent/90 shadow-2xl z-40 p-0 group"
    >
      <div className="absolute inset-0 rounded-full bg-gradient-to-br from-primary to-accent opacity-0 group-hover:opacity-100 animate-pulse" />
      <Sparkles className="w-6 h-6 text-white relative z-10" />
      <div className="absolute -top-1 -right-1 w-4 h-4 bg-secondary rounded-full flex items-center justify-center">
        <CheckCircle className="w-3 h-3 text-white" />
      </div>
    </Button>
  );
}