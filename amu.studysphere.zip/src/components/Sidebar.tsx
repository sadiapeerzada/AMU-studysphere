import { 
  Home, 
  BookOpen, 
  Calendar, 
  MessageSquare, 
  User, 
  GraduationCap, 
  LogOut, 
  Bell,
  Users,
  UserPlus,
  ListChecks,
  X
} from "lucide-react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { GeometricBorder } from "./IslamicPattern";

interface SidebarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  onLogout: () => void;
  userRole: "student" | "professor";
  isOpen: boolean;
  onClose: () => void;
}

export function Sidebar({ currentView, onNavigate, onLogout, userRole, isOpen, onClose }: SidebarProps) {
  const studentNavItems = [
    { id: "dashboard", label: "Dashboard", icon: Home },
    { id: "notes", label: "Notes Sharing", icon: BookOpen },
    { id: "timetable", label: "Timetable", icon: Calendar },
    { id: "assignments", label: "Assignments", icon: ListChecks },
    { id: "doubts", label: "Doubt-Solving", icon: MessageSquare },
    { id: "announcements", label: "Announcements", icon: Bell },
    { id: "clubs", label: "Clubs", icon: Users },
    { id: "mentorship", label: "Mentorship", icon: UserPlus },
    { id: "profile", label: "Profile", icon: User }
  ];

  const professorNavItems = [
    { id: "dashboard", label: "Dashboard", icon: Home },
    { id: "notes", label: "Notes & Resources", icon: BookOpen },
    { id: "timetable", label: "Schedule", icon: Calendar },
    { id: "announcements", label: "Announcements", icon: Bell },
    { id: "profile", label: "Profile", icon: User }
  ];

  const navItems = userRole === "professor" ? professorNavItems : studentNavItems;

  const handleNavigate = (id: string) => {
    onNavigate(id);
    onClose();
  };

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 md:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <div className={`
        fixed md:sticky top-0 left-0 h-screen
        w-64 bg-white border-r border-border z-50
        flex flex-col
        transform transition-transform duration-300 ease-in-out
        ${isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
      `}>
        {/* Header */}
        <div className="p-6 border-b border-border relative overflow-hidden">
          <div className="absolute top-0 left-0 right-0">
            <GeometricBorder className="text-primary" />
          </div>
          <div className="flex items-center justify-between relative z-10">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center shadow-lg">
                <GraduationCap className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-primary">AMU StudySphere</h3>
                <p className="text-muted-foreground">
                  {userRole === "professor" ? "Faculty Portal" : "Student Portal"}
                </p>
              </div>
            </div>
            {/* Mobile Close Button */}
            <Button
              variant="ghost"
              size="sm"
              className="md:hidden p-2"
              onClick={onClose}
            >
              <X className="w-5 h-5" />
            </Button>
          </div>
          {userRole === "professor" && (
            <Badge className="mt-3 bg-secondary">Professor Mode</Badge>
          )}
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            
            return (
              <button
                key={item.id}
                onClick={() => handleNavigate(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${ 
                  isActive 
                    ? "bg-gradient-to-r from-primary to-secondary text-white shadow-md" 
                    : "text-foreground hover:bg-muted"
                }`}
              >
                <Icon className="w-5 h-5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="p-4 border-t border-border space-y-2">
          <div className="px-4 py-2 bg-primary/5 rounded-lg mb-2">
            <p className="text-muted-foreground">
              {userRole === "professor" ? "Dr. Khan" : "Student"}
            </p>
            <p className="text-primary">
              {userRole === "professor" ? "Computer Science" : "B.Tech CSE"}
            </p>
          </div>
          <Button 
            variant="outline" 
            className="w-full justify-start border-destructive text-destructive hover:bg-destructive hover:text-white"
            onClick={onLogout}
          >
            <LogOut className="w-5 h-5 mr-3" />
            Logout
          </Button>
        </div>
      </div>
    </>
  );
}
