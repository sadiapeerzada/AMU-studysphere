import { useState, useEffect } from "react";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { Footer } from "./Footer";
import { IslamicPattern, GeometricBorder, ArchPattern } from "./IslamicPattern";
import { 
  GraduationCap, 
  BookOpen, 
  MessageSquare, 
  Users, 
  Brain, 
  Globe, 
  Volume2,
  ListChecks,
  Bell,
  Calendar,
  ArrowRight,
  Sparkles,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import { motion } from "motion/react";

// Import actual AMU campus images
import clockTowerImg from "figma:asset/9bf4b717bce84dd651b3be0a69e18d208717c845.png";
import campusBuildingImg from "figma:asset/93f14d528c01d924601017ea47e56d704a9ca7ff.png";
import kennedyAuditoriumImg from "figma:asset/5f7bb67aa6cf4ae58a2d6cadd905bae7fd7bf286.png";
import culturalEventImg from "figma:asset/8472fbe1f1642effdd5f1a0d74f8121e9053493c.png";
import campusArchitectureImg from "figma:asset/8b3f8aa072d8557de21b3a8af21589d650df409c.png";
import historicBuildingImg from "figma:asset/2621a555870e50a82c338cf8718eb50e08058f1c.png";
import backgroundImg from "figma:asset/8b3f8aa072d8557de21b3a8af21589d650df409c.png";

interface LandingPageProps {
  onGetStarted: () => void;
}

export function LandingPage({ onGetStarted }: LandingPageProps) {
  const [currentSlide, setCurrentSlide] = useState(0);

  const campusImages = [
    {
      url: clockTowerImg,
      caption: "Iconic AMU Clock Tower"
    },
    {
      url: campusBuildingImg,
      caption: "Indo-Islamic Architecture"
    },
    {
      url: kennedyAuditoriumImg,
      caption: "Kennedy Auditorium & Cultural Center"
    },
    {
      url: culturalEventImg,
      caption: "Cultural Education Centre - AMU"
    },
    {
      url: campusArchitectureImg,
      caption: "Historic AMU Campus Architecture"
    },
    {
      url: historicBuildingImg,
      caption: "AMU's Architectural Heritage"
    }
  ];

  const features = [
    {
      icon: BookOpen,
      title: "Notes Hub & AI Summarizer",
      description: "Upload, download, and get AI-powered summaries of your notes instantly",
      color: "text-primary",
      bgColor: "bg-primary/10"
    },
    {
      icon: Brain,
      title: "AI Study Assistant",
      description: "Interactive GPT-powered chatbot for step-by-step explanations and study guidance",
      color: "text-accent",
      bgColor: "bg-accent/10"
    },
    {
      icon: ListChecks,
      title: "Smart Reminders & To-Do",
      description: "Never miss a deadline with intelligent task management linked to your schedule",
      color: "text-blue-600",
      bgColor: "bg-blue-100"
    },
    {
      icon: Users,
      title: "Club Communities",
      description: "Join clubs, follow updates, and receive AI-generated summaries and notifications",
      color: "text-secondary",
      bgColor: "bg-secondary/10"
    },
    {
      icon: MessageSquare,
      title: "Doubt-Solving Forums",
      description: "Ask questions, get answers from peers and professors in real-time",
      color: "text-purple-600",
      bgColor: "bg-purple-100"
    },
    {
      icon: Globe,
      title: "Multi-Language Support",
      description: "Access content in English, Urdu, and Hindi with real-time translation",
      color: "text-green-600",
      bgColor: "bg-green-100"
    },
    {
      icon: Volume2,
      title: "Audio Mode",
      description: "Listen to your notes and study materials with text-to-speech accessibility",
      color: "text-orange-600",
      bgColor: "bg-orange-100"
    },
    {
      icon: Bell,
      title: "Smart Notices",
      description: "Get important announcements with AI-powered summarization and categorization",
      color: "text-pink-600",
      bgColor: "bg-pink-100"
    },
    {
      icon: Calendar,
      title: "Timetable Management",
      description: "Sync your class schedule and get smart reminders for upcoming sessions",
      color: "text-indigo-600",
      bgColor: "bg-indigo-100"
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % campusImages.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [campusImages.length]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % campusImages.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + campusImages.length) % campusImages.length);
  };

  return (
    <div className="min-h-screen relative">
      {/* Background Image */}
      <div className="fixed inset-0 z-0">
        <img
          src={backgroundImg}
          alt="AMU Campus Architecture"
          className="w-full h-full object-cover"
        />
        {/* Dark overlay for better readability */}
        <div className="absolute inset-0 bg-gradient-to-br from-black/75 via-black/70 to-black/65"></div>
      </div>

      {/* Header with Logo */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-black/20 backdrop-blur-md border-b border-white/10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-accent via-primary to-secondary rounded-lg flex items-center justify-center shadow-xl">
              <GraduationCap className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="text-white">AMU StudySphere</h2>
              <p className="text-white/70">Aligarh Muslim University</p>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden z-10">
        {/* Subtle Pattern Overlay */}
        <div className="absolute inset-0 text-primary pointer-events-none opacity-20">
          <IslamicPattern opacity={0.1} />
        </div>

        {/* Decorative Arches */}
        <div className="absolute top-0 left-0 right-0 h-32 text-accent/20">
          <ArchPattern />
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left: Text Content */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center lg:text-left"
            >
              <div className="inline-flex items-center gap-3 mb-6 px-4 py-2 bg-accent/20 backdrop-blur-sm rounded-full border border-accent/40">
                <Sparkles className="w-5 h-5 text-accent" />
                <span className="text-accent">Powered by AI</span>
              </div>

              <h1 className="mb-4 text-white drop-shadow-lg">
                Welcome to amu.studysphere
              </h1>

              <p className="text-white/90 mb-2 max-w-xl mx-auto lg:mx-0 drop-shadow-md">
                Your complete campus ecosystem for learning, collaboration, and growth at Aligarh Muslim University
              </p>

              <div className="flex flex-wrap gap-3 justify-center lg:justify-start mb-8">
                <div className="flex items-center gap-2 px-3 py-1 bg-white/10 backdrop-blur-sm rounded-full border border-white/20">
                  <div className="w-2 h-2 bg-accent rounded-full animate-pulse"></div>
                  <span className="text-white/90">AI-Powered Tools</span>
                </div>
                <div className="flex items-center gap-2 px-3 py-1 bg-white/10 backdrop-blur-sm rounded-full border border-white/20">
                  <div className="w-2 h-2 bg-accent rounded-full animate-pulse"></div>
                  <span className="text-white/90">Multi-Language</span>
                </div>
                <div className="flex items-center gap-2 px-3 py-1 bg-white/10 backdrop-blur-sm rounded-full border border-white/20">
                  <div className="w-2 h-2 bg-accent rounded-full animate-pulse"></div>
                  <span className="text-white/90">Smart Collaboration</span>
                </div>
              </div>

              <Button
                size="lg"
                onClick={onGetStarted}
                className="bg-gradient-to-r from-accent via-primary to-secondary hover:opacity-90 transition-opacity h-14 px-8 shadow-2xl group"
              >
                <span>Get Started</span>
                <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>

              <p className="mt-4 text-white/80 drop-shadow-md">
                Join thousands of AMU students already using StudySphere
              </p>
            </motion.div>

            {/* Right: Image Carousel */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="relative"
            >
              <Card className="border-accent/30 shadow-2xl overflow-hidden bg-white/10 backdrop-blur-md">
                <CardContent className="p-0">
                  <div className="relative h-[400px] lg:h-[500px]">
                    {campusImages.map((image, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: index === currentSlide ? 1 : 0 }}
                        transition={{ duration: 0.5 }}
                        className="absolute inset-0"
                      >
                        <img
                          src={image.url}
                          alt={image.caption}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-6">
                          <p className="text-white drop-shadow-lg">{image.caption}</p>
                        </div>
                      </motion.div>
                    ))}

                    {/* Navigation Buttons */}
                    <button
                      onClick={prevSlide}
                      className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/80 backdrop-blur rounded-full flex items-center justify-center hover:bg-white transition-colors shadow-lg"
                    >
                      <ChevronLeft className="w-5 h-5" />
                    </button>
                    <button
                      onClick={nextSlide}
                      className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/80 backdrop-blur rounded-full flex items-center justify-center hover:bg-white transition-colors shadow-lg"
                    >
                      <ChevronRight className="w-5 h-5" />
                    </button>

                    {/* Dots Indicator */}
                    <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                      {campusImages.map((_, index) => (
                        <button
                          key={index}
                          onClick={() => setCurrentSlide(index)}
                          className={`w-2 h-2 rounded-full transition-all ${
                            index === currentSlide
                              ? "bg-white w-6"
                              : "bg-white/50 hover:bg-white/80"
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Floating Badge */}
              <motion.div
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 3, repeat: Infinity }}
                className="absolute -top-4 -right-4 bg-accent text-black px-4 py-2 rounded-full shadow-xl border-2 border-white/20"
              >
                <div className="flex items-center gap-2">
                  <GraduationCap className="w-5 h-5" />
                  <span>AMU Official</span>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 text-white/70"
        >
          <div className="flex flex-col items-center gap-2">
            <span className="text-sm drop-shadow-md">Scroll to explore</span>
            <div className="w-6 h-10 border-2 border-white/70 rounded-full flex items-start justify-center p-2">
              <div className="w-1 h-2 bg-white/70 rounded-full"></div>
            </div>
          </div>
        </motion.div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 relative bg-background z-10">
        <div className="absolute inset-0 text-secondary pointer-events-none">
          <IslamicPattern opacity={0.02} />
        </div>

        <div className="container mx-auto relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <div className="inline-flex items-center gap-2 mb-4 px-4 py-2 bg-secondary/10 rounded-full border border-secondary/20">
              <Sparkles className="w-4 h-4 text-secondary" />
              <span className="text-secondary">Powerful Features</span>
            </div>
            <h2 className="mb-4">Everything You Need to Succeed</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              StudySphere combines cutting-edge AI technology with intuitive design to create the ultimate campus companion
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <Card className="border-border hover:border-primary/30 transition-all duration-300 hover:shadow-xl h-full group cursor-pointer">
                    <CardContent className="p-6">
                      <div className={`w-14 h-14 ${feature.bgColor} rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                        <Icon className={`w-7 h-7 ${feature.color}`} />
                      </div>
                      <h3 className="mb-2 group-hover:text-primary transition-colors">
                        {feature.title}
                      </h3>
                      <p className="text-muted-foreground">
                        {feature.description}
                      </p>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-primary/10 via-secondary/10 to-accent/10 relative overflow-hidden z-10">
        <div className="absolute inset-0 text-accent pointer-events-none">
          <IslamicPattern opacity={0.05} />
        </div>
        <GeometricBorder className="text-primary absolute top-0 left-0 right-0" />

        <div className="container mx-auto relative z-10">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            {[
              { value: "10,000+", label: "Active Students" },
              { value: "500+", label: "Professors" },
              { value: "50+", label: "Active Clubs" },
              { value: "100K+", label: "Notes Shared" }
            ].map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.5 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="border-border shadow-lg bg-white/80 backdrop-blur">
                  <CardContent className="p-6">
                    <div className="text-primary mb-2">{stat.value}</div>
                    <p className="text-muted-foreground">{stat.label}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        <GeometricBorder className="text-primary absolute bottom-0 left-0 right-0 rotate-180" />
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-background relative z-10">
        <div className="container mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <Card className="border-primary/30 shadow-2xl overflow-hidden relative">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-secondary/5 to-accent/5">
                <IslamicPattern opacity={0.05} className="text-primary" />
              </div>
              
              <CardContent className="p-12 text-center relative z-10">
                <div className="max-w-2xl mx-auto">
                  <div className="w-20 h-20 bg-gradient-to-br from-primary to-secondary rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-xl">
                    <GraduationCap className="w-10 h-10 text-white" />
                  </div>
                  
                  <h2 className="mb-4">Ready to Transform Your Campus Experience?</h2>
                  <p className="text-muted-foreground mb-8">
                    Join the StudySphere community today and discover a smarter way to learn, collaborate, and succeed at AMU
                  </p>

                  <Button
                    size="lg"
                    onClick={onGetStarted}
                    className="bg-gradient-to-r from-primary via-secondary to-accent hover:opacity-90 transition-opacity h-14 px-10 shadow-2xl group"
                  >
                    <span>Get Started Now</span>
                    <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                  </Button>

                  <p className="mt-6 text-muted-foreground">
                    Free for all AMU students and professors
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <div className="px-4 pb-8">
        <div className="container mx-auto">
          <Footer />
        </div>
      </div>
    </div>
  );
}