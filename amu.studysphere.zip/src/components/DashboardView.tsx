import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { BookOpen, Calendar, ClipboardCheck, TrendingUp, Clock, AlertCircle, Users, Bell, MessageSquare, Sparkles, Trophy, ArrowRight } from "lucide-react";
import { motion } from "motion/react";
import { IslamicPattern, GeometricBorder } from "./IslamicPattern";

interface DashboardViewProps {
  onNavigate: (view: string) => void;
}

export function DashboardView({ onNavigate }: DashboardViewProps) {
  const [notes, setNotes] = useState<any[]>([]);
  const [assignments, setAssignments] = useState<any[]>([]);
  const [timetable, setTimetable] = useState<any[]>([]);
  const isDark = document.documentElement.classList.contains("dark");

  useEffect(() => {
    // Load data from localStorage
    const savedNotes = JSON.parse(localStorage.getItem("amu_notes") || "[]");
    const savedAssignments = JSON.parse(localStorage.getItem("amu_assignments") || "[]");
    const savedTimetable = JSON.parse(localStorage.getItem("amu_timetable") || "[]");
    
    setNotes(savedNotes);
    setAssignments(savedAssignments);
    setTimetable(savedTimetable);
  }, []);

  const stats = [
    {
      title: "Total Notes",
      value: notes.length,
      icon: BookOpen,
      color: "from-blue-500 to-cyan-500",
      bgColor: isDark ? "bg-blue-500/10" : "bg-blue-50",
      iconColor: "text-blue-500"
    },
    {
      title: "Assignments",
      value: assignments.length,
      icon: ClipboardCheck,
      color: "from-purple-500 to-pink-500",
      bgColor: isDark ? "bg-purple-500/10" : "bg-purple-50",
      iconColor: "text-purple-500"
    },
    {
      title: "Classes Today",
      value: timetable.filter(t => {
        const today = new Date().toLocaleDateString();
        return t.date === today;
      }).length,
      icon: Calendar,
      color: "from-green-500 to-emerald-500",
      bgColor: isDark ? "bg-green-500/10" : "bg-green-50",
      iconColor: "text-green-500"
    },
    {
      title: "Pending Tasks",
      value: assignments.filter((a: any) => !a.completed).length,
      icon: AlertCircle,
      color: "from-orange-500 to-red-500",
      bgColor: isDark ? "bg-orange-500/10" : "bg-orange-50",
      iconColor: "text-orange-500"
    }
  ];

  const upcomingClasses = timetable
    .slice(0, 3)
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  const recentNotes = notes.slice(0, 4);
  const upcomingAssignments = assignments
    .filter((a: any) => !a.completed)
    .slice(0, 4);

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <h2 className={`mb-2 ${isDark ? "text-white" : "text-slate-900"}`}>
          Welcome back! 👋
        </h2>
        <p className={isDark ? "text-slate-400" : "text-slate-600"}>
          Here's what's happening with your studies today
        </p>
      </motion.div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={stat.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 * (index + 1) }}
            >
              <Card className={`border transition-all duration-300 hover:shadow-xl hover:-translate-y-1 ${
                isDark 
                  ? "bg-slate-800/50 border-slate-700/50 hover:border-slate-600" 
                  : "bg-white/80 backdrop-blur-sm border-slate-200 hover:border-slate-300 hover:shadow-primary/5"
              }`}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className={`text-sm mb-1 ${isDark ? "text-slate-400" : "text-slate-600"}`}>
                        {stat.title}
                      </p>
                      <h3 className={isDark ? "text-white" : "text-slate-900"}>
                        {stat.value}
                      </h3>
                    </div>
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${stat.bgColor}`}>
                      <Icon className={`w-6 h-6 ${stat.iconColor}`} />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {/* Content Grid */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Upcoming Classes */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card className={`border ${
            isDark 
              ? "bg-slate-800/50 border-slate-700/50" 
              : "bg-white/80 backdrop-blur-sm border-slate-200"
          }`}>
            <CardHeader>
              <CardTitle className={`flex items-center gap-2 ${isDark ? "text-white" : "text-slate-900"}`}>
                <Calendar className="w-5 h-5 text-primary" />
                Upcoming Classes
              </CardTitle>
            </CardHeader>
            <CardContent>
              {upcomingClasses.length > 0 ? (
                <div className="space-y-3">
                  {upcomingClasses.map((classItem: any, index: number) => (
                    <div
                      key={index}
                      className={`p-4 rounded-lg border transition-all duration-300 hover:shadow-md ${
                        isDark 
                          ? "bg-slate-900/50 border-slate-700 hover:border-primary" 
                          : "bg-slate-50 border-slate-200 hover:border-primary"
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className={isDark ? "text-white" : "text-slate-900"}>
                            {classItem.courseName}
                          </h4>
                          <div className="flex items-center gap-2 mt-1">
                            <Clock className={`w-3 h-3 ${isDark ? "text-slate-400" : "text-slate-500"}`} />
                            <span className={`text-sm ${isDark ? "text-slate-400" : "text-slate-600"}`}>
                              {classItem.time}
                            </span>
                          </div>
                        </div>
                        <span className={`text-xs px-2 py-1 rounded ${
                          isDark ? "bg-primary/20 text-primary" : "bg-primary/10 text-primary"
                        }`}>
                          {classItem.day}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className={`text-center py-8 ${isDark ? "text-slate-500" : "text-slate-400"}`}>
                  No upcoming classes. Add your schedule!
                </p>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Recent Notes */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.6 }}
        >
          <Card className={`border ${
            isDark 
              ? "bg-slate-800/50 border-slate-700/50" 
              : "bg-white/80 backdrop-blur-sm border-slate-200"
          }`}>
            <CardHeader>
              <CardTitle className={`flex items-center gap-2 ${isDark ? "text-white" : "text-slate-900"}`}>
                <BookOpen className="w-5 h-5 text-primary" />
                Recent Notes
              </CardTitle>
            </CardHeader>
            <CardContent>
              {recentNotes.length > 0 ? (
                <div className="space-y-3">
                  {recentNotes.map((note: any, index: number) => (
                    <div
                      key={index}
                      className={`p-4 rounded-lg border transition-all duration-300 hover:shadow-md ${
                        isDark 
                          ? "bg-slate-900/50 border-slate-700 hover:border-secondary" 
                          : "bg-slate-50 border-slate-200 hover:border-secondary"
                      }`}
                    >
                      <h4 className={isDark ? "text-white" : "text-slate-900"}>
                        {note.title}
                      </h4>
                      <p className={`text-sm mt-1 ${isDark ? "text-slate-400" : "text-slate-600"}`}>
                        {note.courseName}
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className={`text-center py-8 ${isDark ? "text-slate-500" : "text-slate-400"}`}>
                  No notes yet. Start adding notes!
                </p>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Pending Assignments */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
      >
        <Card className={`border ${
          isDark 
            ? "bg-slate-800/50 border-slate-700/50" 
            : "bg-white/80 backdrop-blur-sm border-slate-200"
        }`}>
          <CardHeader>
            <CardTitle className={`flex items-center gap-2 ${isDark ? "text-white" : "text-slate-900"}`}>
              <ClipboardCheck className="w-5 h-5 text-primary" />
              Pending Assignments
            </CardTitle>
          </CardHeader>
          <CardContent>
            {upcomingAssignments.length > 0 ? (
              <div className="grid sm:grid-cols-2 gap-4">
                {upcomingAssignments.map((assignment: any, index: number) => (
                  <div
                    key={index}
                    className={`p-4 rounded-lg border transition-all duration-300 hover:shadow-md ${
                      isDark 
                        ? "bg-slate-900/50 border-slate-700 hover:border-accent" 
                        : "bg-slate-50 border-slate-200 hover:border-accent"
                    }`}
                  >
                    <h4 className={isDark ? "text-white" : "text-slate-900"}>
                      {assignment.title}
                    </h4>
                    <p className={`text-sm mt-1 ${isDark ? "text-slate-400" : "text-slate-600"}`}>
                      {assignment.courseName}
                    </p>
                    <div className="flex items-center gap-2 mt-2">
                      <Clock className={`w-3 h-3 ${isDark ? "text-slate-500" : "text-slate-400"}`} />
                      <span className={`text-xs ${isDark ? "text-slate-500" : "text-slate-500"}`}>
                        Due: {assignment.dueDate}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className={`text-center py-8 ${isDark ? "text-slate-500" : "text-slate-400"}`}>
                No pending assignments. You're all caught up! 🎉
              </p>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
