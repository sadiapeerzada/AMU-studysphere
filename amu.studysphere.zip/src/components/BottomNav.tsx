import { Home, BookOpen, Calendar, Bell, User } from "lucide-react";

interface BottomNavProps {
  currentView: string;
  onNavigate: (view: string) => void;
  userRole: "student" | "professor";
}

export function BottomNav({ currentView, onNavigate, userRole }: BottomNavProps) {
  const studentNavItems = [
    { id: "dashboard", label: "Home", icon: Home },
    { id: "notes", label: "Notes", icon: BookOpen },
    { id: "timetable", label: "Schedule", icon: Calendar },
    { id: "announcements", label: "Notices", icon: Bell },
    { id: "profile", label: "Profile", icon: User }
  ];

  const professorNavItems = [
    { id: "dashboard", label: "Home", icon: Home },
    { id: "notes", label: "Notes", icon: BookOpen },
    { id: "timetable", label: "Schedule", icon: Calendar },
    { id: "announcements", label: "Notices", icon: Bell },
    { id: "profile", label: "Profile", icon: User }
  ];

  const navItems = userRole === "professor" ? professorNavItems : studentNavItems;

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-border md:hidden z-50 shadow-lg">
      <div className="flex items-center justify-around py-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`flex flex-col items-center justify-center py-2 px-4 transition-colors ${
                isActive ? "text-primary" : "text-muted-foreground"
              }`}
            >
              <Icon className="w-5 h-5 mb-1" />
              <span className="text-xs">{item.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}