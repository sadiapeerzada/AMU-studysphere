import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { IslamicPattern, GeometricBorder } from "./IslamicPattern";
import { 
  BookOpen, 
  Calendar, 
  MessageSquare, 
  Bell, 
  Users, 
  UserPlus,
  Sparkles,
  Trophy,
  BookMarked,
  Search
} from "lucide-react";
import { useState, useEffect } from "react";

interface NewDashboardProps {
  onNavigate: (screen: string) => void;
}

export function NewDashboard({ onNavigate }: NewDashboardProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<any[]>([]);

  // Search across notes and assignments
  useEffect(() => {
    if (searchQuery.trim()) {
      const notes = JSON.parse(localStorage.getItem("amu_notes") || "[]");
      const assignments = JSON.parse(localStorage.getItem("amu_assignments") || "[]");
      
      const noteResults = notes
        .filter((note: any) =>
          note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          note.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
          note.description?.toLowerCase().includes(searchQuery.toLowerCase())
        )
        .map((note: any) => ({ ...note, type: "note" }));
      
      const assignmentResults = assignments
        .filter((assignment: any) =>
          assignment.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          assignment.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
          assignment.description?.toLowerCase().includes(searchQuery.toLowerCase())
        )
        .map((assignment: any) => ({ ...assignment, type: "assignment" }));
      
      setSearchResults([...noteResults, ...assignmentResults]);
    } else {
      setSearchResults([]);
    }
  }, [searchQuery]);

  const quickLinks = [
    {
      id: "notes",
      title: "Notes",
      description: "Share & access",
      icon: BookOpen,
      color: "text-primary",
      gradient: "from-primary/10 to-primary/5",
      borderColor: "border-primary/20"
    },
    {
      id: "timetable",
      title: "Timetable",
      description: "Schedule & classes",
      icon: Calendar,
      color: "text-blue-600",
      gradient: "from-blue-100 to-blue-50",
      borderColor: "border-blue-200"
    },
    {
      id: "doubts",
      title: "Doubts",
      description: "Q&A forum",
      icon: MessageSquare,
      color: "text-purple-600",
      gradient: "from-purple-100 to-purple-50",
      borderColor: "border-purple-200"
    },
    {
      id: "notices",
      title: "Notices",
      description: "Updates & events",
      icon: Bell,
      color: "text-secondary",
      gradient: "from-secondary/10 to-secondary/5",
      borderColor: "border-secondary/20"
    },
    {
      id: "clubs",
      title: "Clubs",
      description: "Communities",
      icon: Users,
      color: "text-accent",
      gradient: "from-accent/20 to-accent/10",
      borderColor: "border-accent/30"
    },
    {
      id: "mentorship",
      title: "Mentorship",
      description: "Connect & grow",
      icon: UserPlus,
      color: "text-emerald-600",
      gradient: "from-emerald-100 to-emerald-50",
      borderColor: "border-emerald-200"
    }
  ];

  return (
    <div className="space-y-6">
      {/* Welcome Banner with Islamic Pattern */}
      <Card className="border-border overflow-hidden relative">
        <div className="absolute inset-0 text-primary">
          <IslamicPattern opacity={0.04} />
        </div>
        <div className="absolute top-0 left-0 right-0">
          <GeometricBorder className="text-primary" />
        </div>
        <CardContent className="p-6 relative z-10">
          <div className="flex items-start justify-between">
            <div>
              <h2 className="text-primary mb-1">As-salamu alaykum, Ahmed!</h2>
              <p className="text-muted-foreground">B.Tech Computer Science • Semester 6</p>
              <Badge className="bg-accent text-accent-foreground mt-3">
                <Trophy className="w-3 h-3 mr-1" />
                85% Average
              </Badge>
            </div>
            <Sparkles className="w-6 h-6 text-accent" />
          </div>
        </CardContent>
      </Card>

      {/* Global Search */}
      <Card className="border-border">
        <CardContent className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              placeholder="Search across notes, assignments, and more..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          {searchResults.length > 0 && (
            <div className="mt-4 space-y-2 max-h-64 overflow-y-auto">
              {searchResults.map((result, index) => (
                <div
                  key={index}
                  className="p-3 bg-muted/50 rounded-lg hover:bg-muted cursor-pointer transition-colors"
                  onClick={() => {
                    if (result.type === "note") {
                      onNavigate("notes");
                    } else if (result.type === "assignment") {
                      onNavigate("todo");
                    }
                    setSearchQuery("");
                  }}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1">
                      <h4 className="mb-1">{result.title}</h4>
                      <p className="text-muted-foreground line-clamp-1">
                        {result.description || result.subject}
                      </p>
                    </div>
                    <Badge variant="secondary">
                      {result.type === "note" ? "Note" : "Assignment"}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Event Banner */}
      <Card className="border-secondary/30 bg-gradient-to-r from-secondary/5 to-primary/5 relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-32 opacity-10">
          <IslamicPattern />
        </div>
        <CardContent className="p-4 relative z-10">
          <div className="flex items-center gap-3">
            <div className="bg-secondary text-white p-2 rounded-lg">
              <BookMarked className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <h4 className="mb-1">Tech Fest 2025 - Register Now!</h4>
              <p className="text-muted-foreground">3 days of hackathons, workshops & competitions</p>
            </div>
            <Button size="sm" variant="outline" className="border-secondary text-secondary">
              View
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Quick Links Grid */}
      <div>
        <h3 className="mb-4">Quick Access</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {quickLinks.map((link) => {
            const Icon = link.icon;
            return (
              <Card 
                key={link.id}
                className={`cursor-pointer hover:shadow-lg transition-all border ${link.borderColor} bg-gradient-to-br ${link.gradient} group`}
                onClick={() => onNavigate(link.id)}
              >
                <CardContent className="p-4 text-center">
                  <div className="flex justify-center mb-3">
                    <div className={`${link.color} p-3 rounded-xl bg-white shadow-sm group-hover:scale-110 transition-transform`}>
                      <Icon className="w-6 h-6" />
                    </div>
                  </div>
                  <h4 className="mb-1">{link.title}</h4>
                  <p className="text-muted-foreground">{link.description}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Quick Stats */}
      <Card className="border-border">
        <CardContent className="p-6">
          <h4 className="mb-4">Today's Overview</h4>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-primary mb-1">4</div>
              <p className="text-muted-foreground">Classes</p>
            </div>
            <div>
              <div className="text-secondary mb-1">12</div>
              <p className="text-muted-foreground">New Notes</p>
            </div>
            <div>
              <div className="text-accent mb-1">3</div>
              <p className="text-muted-foreground">Notices</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}