import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { IslamicPattern, GeometricBorder } from "./IslamicPattern";
import { 
  BookOpen, 
  Users, 
  FileText, 
  TrendingUp,
  Sparkles,
  Languages,
  HelpCircle,
  Upload,
  Calendar
} from "lucide-react";
import { useState } from "react";

interface ProfessorDashboardProps {
  onNavigate: (screen: string) => void;
}

export function ProfessorDashboard({ onNavigate }: ProfessorDashboardProps) {
  const [showQuizGen, setShowQuizGen] = useState(false);
  const [notesContent, setNotesContent] = useState("");

  const handleGenerateQuiz = () => {
    alert("📝 AI Quiz Generated Successfully!\n\n**Quiz: Object-Oriented Programming**\n\n1. Multiple Choice Questions (5)\n2. True/False Questions (3)\n3. Short Answer Questions (2)\n\nDifficulty: Mixed\nEstimated Time: 20 minutes\n\nQuiz has been saved to your course materials.");
  };

  const handleTranslateNotes = () => {
    alert("🌐 Translation Complete!\n\nYour lecture notes have been translated to:\n• Urdu\n• Hindi\n\nBoth versions are ready for upload and will help students who prefer learning in their native language.");
  };

  const stats = [
    { label: "Students", value: "240", icon: Users, color: "text-primary" },
    { label: "Courses", value: "4", icon: BookOpen, color: "text-secondary" },
    { label: "Lectures", value: "68", icon: FileText, color: "text-blue-600" },
    { label: "Avg. Score", value: "78%", icon: TrendingUp, color: "text-accent" }
  ];

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <Card className="border-border overflow-hidden relative">
        <div className="absolute inset-0 text-primary">
          <IslamicPattern opacity={0.04} />
        </div>
        <div className="absolute top-0 left-0 right-0">
          <GeometricBorder className="text-primary" />
        </div>
        <CardContent className="p-6 relative z-10">
          <div className="flex items-start justify-between">
            <div>
              <h2 className="text-primary mb-1">As-salamu alaykum, Dr. Khan!</h2>
              <p className="text-muted-foreground">Professor • Computer Science Department</p>
              <div className="flex items-center gap-2 mt-3">
                <Badge className="bg-primary">4 Active Courses</Badge>
                <Badge className="bg-accent text-accent-foreground">240 Students</Badge>
              </div>
            </div>
            <Sparkles className="w-6 h-6 text-accent" />
          </div>
        </CardContent>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} className="border-border">
              <CardContent className="p-4 text-center">
                <Icon className={`w-6 h-6 ${stat.color} mx-auto mb-2`} />
                <div className="mb-1">{stat.value}</div>
                <p className="text-muted-foreground">{stat.label}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* AI Tools for Professors */}
      <Card className="border-primary/30 bg-gradient-to-br from-primary/5 to-accent/5 relative overflow-hidden">
        <div className="absolute top-0 left-0 right-0">
          <GeometricBorder className="text-primary" />
        </div>
        <CardHeader className="pt-6">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <CardTitle>AI-Powered Teaching Tools</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-muted-foreground">
            Enhance your teaching with AI assistance - generate quizzes, translate materials, and more
          </p>

          {/* Quiz Generator */}
          <div className="space-y-3">
            <Button
              variant="outline"
              className="w-full justify-between h-auto p-4 border-primary/30 hover:bg-primary/5"
              onClick={() => setShowQuizGen(!showQuizGen)}
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                  <HelpCircle className="w-5 h-5 text-primary" />
                </div>
                <div className="text-left">
                  <h4 className="mb-1">Quiz Generator</h4>
                  <p className="text-muted-foreground">Create practice tests from your lecture notes</p>
                </div>
              </div>
              <span className="text-2xl">{showQuizGen ? "−" : "+"}</span>
            </Button>

            {showQuizGen && (
              <Card className="border-border bg-white">
                <CardContent className="p-4 space-y-3">
                  <label className="block">Paste your lecture notes or content:</label>
                  <Textarea
                    placeholder="Enter the content from which you want to generate quiz questions..."
                    value={notesContent}
                    onChange={(e) => setNotesContent(e.target.value)}
                    className="min-h-[120px] border-border"
                  />
                  <div className="flex gap-2">
                    <Button
                      className="bg-primary hover:bg-primary/90 flex-1"
                      disabled={!notesContent.trim()}
                      onClick={handleGenerateQuiz}
                    >
                      Generate Quiz
                    </Button>
                    <Button variant="outline">
                      Settings
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Translator */}
          <Button
            variant="outline"
            className="w-full justify-between h-auto p-4 border-purple-200 hover:bg-purple-50"
            onClick={handleTranslateNotes}
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                <Languages className="w-5 h-5 text-purple-600" />
              </div>
              <div className="text-left">
                <h4 className="mb-1">Translate Lecture Notes</h4>
                <p className="text-muted-foreground">Convert to Urdu or Hindi before upload</p>
              </div>
            </div>
            <span className="text-primary">→</span>
          </Button>

          {/* Summarizer */}
          <Button
            variant="outline"
            className="w-full justify-between h-auto p-4 border-blue-200 hover:bg-blue-50"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <FileText className="w-5 h-5 text-blue-600" />
              </div>
              <div className="text-left">
                <h4 className="mb-1">Summarize Lecture Material</h4>
                <p className="text-muted-foreground">Create concise study guides for students</p>
              </div>
            </div>
            <span className="text-primary">→</span>
          </Button>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div>
        <h3 className="mb-4">Quick Actions</h3>
        <div className="grid grid-cols-2 gap-3">
          <Card 
            className="cursor-pointer hover:shadow-lg transition-all border-primary/20 bg-gradient-to-br from-primary/5 to-primary/10"
            onClick={() => onNavigate("notes")}
          >
            <CardContent className="p-4 text-center">
              <div className="flex justify-center mb-3">
                <div className="text-primary p-3 rounded-xl bg-white shadow-sm">
                  <Upload className="w-6 h-6" />
                </div>
              </div>
              <h4 className="mb-1">Upload Notes</h4>
              <p className="text-muted-foreground">Share materials</p>
            </CardContent>
          </Card>

          <Card 
            className="cursor-pointer hover:shadow-lg transition-all border-secondary/20 bg-gradient-to-br from-secondary/5 to-secondary/10"
            onClick={() => onNavigate("notices")}
          >
            <CardContent className="p-4 text-center">
              <div className="flex justify-center mb-3">
                <div className="text-secondary p-3 rounded-xl bg-white shadow-sm">
                  <FileText className="w-6 h-6" />
                </div>
              </div>
              <h4 className="mb-1">Post Notice</h4>
              <p className="text-muted-foreground">Announcements</p>
            </CardContent>
          </Card>

          <Card 
            className="cursor-pointer hover:shadow-lg transition-all border-blue-200 bg-gradient-to-br from-blue-50 to-blue-100"
            onClick={() => onNavigate("timetable")}
          >
            <CardContent className="p-4 text-center">
              <div className="flex justify-center mb-3">
                <div className="text-blue-600 p-3 rounded-xl bg-white shadow-sm">
                  <Calendar className="w-6 h-6" />
                </div>
              </div>
              <h4 className="mb-1">Schedule</h4>
              <p className="text-muted-foreground">View classes</p>
            </CardContent>
          </Card>

          <Card 
            className="cursor-pointer hover:shadow-lg transition-all border-accent/30 bg-gradient-to-br from-accent/10 to-accent/20"
            onClick={() => onNavigate("doubts")}
          >
            <CardContent className="p-4 text-center">
              <div className="flex justify-center mb-3">
                <div className="text-accent p-3 rounded-xl bg-white shadow-sm">
                  <Users className="w-6 h-6" />
                </div>
              </div>
              <h4 className="mb-1">Student Q&A</h4>
              <p className="text-muted-foreground">Answer doubts</p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Recent Activity */}
      <Card className="border-border">
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center gap-3 pb-3 border-b border-border">
            <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
              <BookOpen className="w-5 h-5 text-primary" />
            </div>
            <div className="flex-1">
              <h4 className="mb-1">New notes uploaded</h4>
              <p className="text-muted-foreground">Data Structures - Chapter 5</p>
            </div>
            <span className="text-muted-foreground">2h ago</span>
          </div>

          <div className="flex items-center gap-3 pb-3 border-b border-border">
            <div className="w-10 h-10 bg-secondary/10 rounded-lg flex items-center justify-center">
              <HelpCircle className="w-5 h-5 text-secondary" />
            </div>
            <div className="flex-1">
              <h4 className="mb-1">3 new student questions</h4>
              <p className="text-muted-foreground">In OOP discussion forum</p>
            </div>
            <span className="text-muted-foreground">5h ago</span>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-accent/20 rounded-lg flex items-center justify-center">
              <Users className="w-5 h-5 text-accent" />
            </div>
            <div className="flex-1">
              <h4 className="mb-1">Class attendance recorded</h4>
              <p className="text-muted-foreground">CS-302 - 95% attendance</p>
            </div>
            <span className="text-muted-foreground">1d ago</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}