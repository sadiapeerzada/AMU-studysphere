import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { MessageCircle, Plus, ThumbsUp, CheckCircle, Search, Filter } from "lucide-react";
import { useState, useEffect } from "react";
import { toast } from "sonner@2.0.3";

interface Doubt {
  id: string;
  question: string;
  description: string;
  askedBy: string;
  subject: string;
  time: string;
  answers: number;
  likes: number;
  status: "answered" | "pending";
}

export function DoubtSolving() {
  const [showAskForm, setShowAskForm] = useState(false);
  const [doubts, setDoubts] = useState<Doubt[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterSubject, setFilterSubject] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [newDoubt, setNewDoubt] = useState({
    question: "",
    description: "",
    subject: "",
    askedBy: "Current User"
  });

  // Load doubts from localStorage
  useEffect(() => {
    const storedDoubts = localStorage.getItem("amu_doubts");
    if (storedDoubts) {
      setDoubts(JSON.parse(storedDoubts));
    } else {
      // Set initial sample doubts
      const sampleDoubts: Doubt[] = [
        {
          id: "1",
          question: "How do I implement a binary search tree in C++?",
          description: "I'm having trouble understanding the insertion and deletion operations.",
          askedBy: "Fatima Zahra",
          subject: "Data Structures",
          time: "2 hours ago",
          answers: 3,
          likes: 12,
          status: "answered"
        },
        {
          id: "2",
          question: "What is the difference between TCP and UDP protocols?",
          description: "Can someone explain with practical examples?",
          askedBy: "Mohd. Ali",
          subject: "Computer Networks",
          time: "5 hours ago",
          answers: 2,
          likes: 8,
          status: "answered"
        },
        {
          id: "3",
          question: "Can someone explain polymorphism with a real-world example?",
          description: "I understand the concept but need practical examples.",
          askedBy: "Aisha Khan",
          subject: "OOP",
          time: "1 day ago",
          answers: 5,
          likes: 15,
          status: "answered"
        },
        {
          id: "4",
          question: "Help needed with SQL JOIN operations",
          description: "Confused about INNER JOIN vs LEFT JOIN",
          askedBy: "Zaid Ahmed",
          subject: "DBMS",
          time: "1 day ago",
          answers: 0,
          likes: 3,
          status: "pending"
        }
      ];
      setDoubts(sampleDoubts);
      localStorage.setItem("amu_doubts", JSON.stringify(sampleDoubts));
    }
  }, []);

  // Save doubts to localStorage
  useEffect(() => {
    if (doubts.length > 0 || localStorage.getItem("amu_doubts")) {
      localStorage.setItem("amu_doubts", JSON.stringify(doubts));
    }
  }, [doubts]);

  const handlePostQuestion = () => {
    if (!newDoubt.question || !newDoubt.subject) {
      toast.error("Please fill in all required fields");
      return;
    }

    const doubt: Doubt = {
      id: Date.now().toString(),
      question: newDoubt.question,
      description: newDoubt.description,
      askedBy: newDoubt.askedBy,
      subject: newDoubt.subject,
      time: "Just now",
      answers: 0,
      likes: 0,
      status: "pending"
    };

    setDoubts(prev => [doubt, ...prev]);
    setShowAskForm(false);
    setNewDoubt({ question: "", description: "", subject: "", askedBy: "Current User" });
    toast.success("Question posted successfully!");
  };

  const handleLikeDoubt = (doubtId: string) => {
    setDoubts(prev => prev.map(doubt =>
      doubt.id === doubtId
        ? { ...doubt, likes: doubt.likes + 1 }
        : doubt
    ));
    toast.success("Liked!");
  };

  // Filter doubts
  const filteredDoubts = doubts.filter(doubt => {
    const matchesSearch = doubt.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         doubt.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         doubt.subject.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSubject = filterSubject === "all" || doubt.subject === filterSubject;
    const matchesStatus = filterStatus === "all" || doubt.status === filterStatus;
    return matchesSearch && matchesSubject && matchesStatus;
  });

  // Get unique subjects
  const subjects = Array.from(new Set(doubts.map(d => d.subject)));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="mb-1">Doubt-Solving Forum</h2>
          <p className="text-muted-foreground">Ask questions and help your peers</p>
        </div>
        <Button 
          className="bg-primary hover:bg-primary/90"
          onClick={() => setShowAskForm(!showAskForm)}
        >
          <Plus className="w-4 h-4 mr-2" />
          Ask Question
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border-primary/30">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-primary/10 rounded-lg">
                <MessageCircle className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-muted-foreground">Total Questions</p>
                <p className="text-primary">{doubts.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-green-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-100 rounded-lg">
                <CheckCircle className="w-5 h-5 text-green-700" />
              </div>
              <div>
                <p className="text-muted-foreground">Answered</p>
                <p className="text-green-700">{doubts.filter(d => d.status === "answered").length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-yellow-200 md:col-span-2">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-yellow-100 rounded-lg">
                <MessageCircle className="w-5 h-5 text-yellow-700" />
              </div>
              <div>
                <p className="text-muted-foreground">Pending Answers</p>
                <p className="text-yellow-700">{doubts.filter(d => d.status === "pending").length} questions</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Ask Question Form */}
      {showAskForm && (
        <Card className="border-primary">
          <CardContent className="p-5 space-y-4">
            <h3>Ask Your Question</h3>
            <div className="space-y-2">
              <Label htmlFor="question">Question *</Label>
              <Input
                id="question"
                placeholder="What's your question?"
                value={newDoubt.question}
                onChange={(e) => setNewDoubt(prev => ({ ...prev, question: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="subject">Subject *</Label>
              <Input
                id="subject"
                placeholder="e.g., Data Structures, OOP, DBMS"
                value={newDoubt.subject}
                onChange={(e) => setNewDoubt(prev => ({ ...prev, subject: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description (Optional)</Label>
              <Textarea 
                id="description"
                placeholder="Provide more details about your question..."
                rows={4}
                value={newDoubt.description}
                onChange={(e) => setNewDoubt(prev => ({ ...prev, description: e.target.value }))}
              />
            </div>
            <div className="flex items-center gap-3">
              <Button className="bg-primary hover:bg-primary/90" onClick={handlePostQuestion}>
                Post Question
              </Button>
              <Button variant="outline" onClick={() => setShowAskForm(false)}>
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Search and Filters */}
      <Card className="border-border">
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search questions..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Select value={filterSubject} onValueChange={setFilterSubject}>
              <SelectTrigger className="sm:w-[180px]">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Subject" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Subjects</SelectItem>
                {subjects.map(subject => (
                  <SelectItem key={subject} value={subject}>{subject}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="sm:w-[150px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="answered">Answered</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Doubts List */}
      <div className="space-y-4">
        {filteredDoubts.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <MessageCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="mb-2">No questions found</h3>
              <p className="text-muted-foreground">
                {searchQuery || filterSubject !== "all" || filterStatus !== "all"
                  ? "Try adjusting your search or filters"
                  : "Be the first to ask a question!"}
              </p>
            </CardContent>
          </Card>
        ) : (
          filteredDoubts.map((doubt) => (
            <Card 
              key={doubt.id}
              className={`border-border hover:shadow-md transition-shadow ${
                doubt.status === "pending" ? "border-l-4 border-l-yellow-500" : "border-l-4 border-l-green-500"
              }`}
            >
              <CardContent className="p-5">
                <div className="flex items-start gap-4">
                  <Avatar className="h-10 w-10">
                    <AvatarFallback className="bg-primary text-white">
                      {doubt.askedBy.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>

                  <div className="flex-1">
                    <div className="flex items-start justify-between gap-4 mb-2">
                      <div className="flex-1">
                        <h4 className="mb-1">{doubt.question}</h4>
                        <div className="flex flex-wrap items-center gap-2 mb-2">
                          <Badge variant="secondary" className="bg-primary/10 text-primary">
                            {doubt.subject}
                          </Badge>
                          <Badge 
                            variant="outline"
                            className={doubt.status === "answered" 
                              ? "border-green-200 text-green-700 bg-green-50" 
                              : "border-yellow-200 text-yellow-700 bg-yellow-50"
                            }
                          >
                            {doubt.status === "answered" ? "Answered" : "Pending"}
                          </Badge>
                        </div>
                      </div>
                    </div>

                    {doubt.description && (
                      <p className="text-muted-foreground mb-3">
                        {doubt.description}
                      </p>
                    )}

                    <div className="flex flex-wrap items-center justify-between gap-4">
                      <div className="flex items-center gap-4 text-muted-foreground">
                        <span>By {doubt.askedBy}</span>
                        <span>•</span>
                        <span>{doubt.time}</span>
                      </div>

                      <div className="flex items-center gap-3">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleLikeDoubt(doubt.id)}
                          className="gap-2"
                        >
                          <ThumbsUp className="w-4 h-4" />
                          <span>{doubt.likes}</span>
                        </Button>
                        <Button size="sm" variant="outline" className="gap-2">
                          <MessageCircle className="w-4 h-4" />
                          <span>{doubt.answers} {doubt.answers === 1 ? 'Answer' : 'Answers'}</span>
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}