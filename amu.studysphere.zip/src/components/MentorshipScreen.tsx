import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { Input } from "./ui/input";
import { UserPlus, Star, BookOpen, Code, Briefcase, Search } from "lucide-react";

export function MentorshipScreen() {
  const mentors = [
    {
      id: 1,
      name: "Dr. Sarah Ahmed",
      role: "Senior Software Engineer",
      company: "Google",
      department: "Computer Science",
      expertise: ["Web Dev", "Cloud", "System Design"],
      rating: 4.9,
      sessions: 45,
      available: true
    },
    {
      id: 2,
      name: "Prof. Zainab Khan",
      role: "ML Research Scientist",
      company: "Microsoft Research",
      department: "AI & ML",
      expertise: ["Machine Learning", "Deep Learning", "NLP"],
      rating: 4.8,
      sessions: 38,
      available: true
    },
    {
      id: 3,
      name: "Mohd. Arif",
      role: "Product Manager",
      company: "Amazon",
      department: "MBA",
      expertise: ["Product Strategy", "Analytics", "Leadership"],
      rating: 4.7,
      sessions: 29,
      available: false
    },
    {
      id: 4,
      name: "Fatima Siddiqui",
      role: "Full Stack Developer",
      company: "Flipkart",
      department: "Computer Science",
      expertise: ["React", "Node.js", "MongoDB"],
      rating: 4.9,
      sessions: 52,
      available: true
    }
  ];

  const myMentor = mentors[0];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="mb-1">Mentorship Program</h2>
        <p className="text-muted-foreground">Connect with alumni and industry experts</p>
      </div>

      {/* My Mentor Card */}
      <Card className="border-primary/30 bg-gradient-to-r from-primary/5 to-accent/5">
        <CardContent className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <UserPlus className="w-5 h-5 text-primary" />
            <h4>Your Mentor</h4>
          </div>
          
          <div className="flex items-start gap-4">
            <Avatar className="w-16 h-16 bg-primary text-white">
              <AvatarFallback>SA</AvatarFallback>
            </Avatar>
            
            <div className="flex-1">
              <h4 className="mb-1">{myMentor.name}</h4>
              <p className="text-muted-foreground mb-2">{myMentor.role} at {myMentor.company}</p>
              
              <div className="flex flex-wrap gap-2 mb-3">
                {myMentor.expertise.map((skill, index) => (
                  <Badge key={index} variant="secondary" className="bg-primary/10 text-primary">
                    {skill}
                  </Badge>
                ))}
              </div>
              
              <div className="flex items-center gap-4 text-muted-foreground mb-3">
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 fill-accent text-accent" />
                  <span>{myMentor.rating}</span>
                </div>
                <span>•</span>
                <span>{myMentor.sessions} sessions</span>
              </div>
              
              <Button size="sm" className="bg-primary hover:bg-primary/90">
                Schedule Session
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input 
          placeholder="Search mentors by expertise, company, or department..."
          className="pl-10 border-border bg-white"
        />
      </div>

      {/* Available Mentors */}
      <div>
        <h3 className="mb-4">Available Mentors</h3>
        <div className="space-y-3">
          {mentors.map((mentor) => (
            <Card 
              key={mentor.id} 
              className={`border-border hover:shadow-md transition-shadow ${!mentor.available && 'opacity-60'}`}
            >
              <CardContent className="p-4">
                <div className="flex items-start gap-4">
                  <Avatar className="w-12 h-12 bg-secondary text-white">
                    <AvatarFallback>
                      {mentor.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div className="flex-1">
                        <h4 className="mb-1 line-clamp-1">{mentor.name}</h4>
                        <p className="text-muted-foreground line-clamp-1">
                          {mentor.role} at {mentor.company}
                        </p>
                      </div>
                      {mentor.available ? (
                        <Badge className="bg-green-100 text-green-700 shrink-0">Available</Badge>
                      ) : (
                        <Badge variant="secondary" className="shrink-0">Busy</Badge>
                      )}
                    </div>
                    
                    <div className="flex flex-wrap gap-2 mb-3">
                      {mentor.expertise.slice(0, 3).map((skill, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                    
                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-1 text-muted-foreground">
                        <Star className="w-3 h-3 fill-accent text-accent" />
                        <span>{mentor.rating}</span>
                      </div>
                      <span className="text-muted-foreground">•</span>
                      <span className="text-muted-foreground">{mentor.sessions} sessions</span>
                    </div>
                  </div>
                  
                  <Button 
                    size="sm" 
                    variant="outline"
                    disabled={!mentor.available}
                    className="shrink-0"
                  >
                    Connect
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Stats */}
      <Card className="border-border">
        <CardContent className="p-6">
          <h4 className="mb-4">Program Benefits</h4>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="bg-primary/10 text-primary p-3 rounded-lg mb-2 mx-auto w-fit">
                <BookOpen className="w-5 h-5" />
              </div>
              <div className="text-primary mb-1">Career</div>
              <p className="text-muted-foreground">Guidance</p>
            </div>
            <div>
              <div className="bg-secondary/10 text-secondary p-3 rounded-lg mb-2 mx-auto w-fit">
                <Code className="w-5 h-5" />
              </div>
              <div className="text-secondary mb-1">Skill</div>
              <p className="text-muted-foreground">Development</p>
            </div>
            <div>
              <div className="bg-accent/20 text-accent p-3 rounded-lg mb-2 mx-auto w-fit">
                <Briefcase className="w-5 h-5" />
              </div>
              <div className="text-accent mb-1">Industry</div>
              <p className="text-muted-foreground">Insights</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}