import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { ThemeCustomizer } from "./ThemeCustomizer";
import { IslamicPattern, GeometricBorder } from "./IslamicPattern";
import { 
  Award, 
  BookOpen, 
  MessageSquare, 
  TrendingUp, 
  Mail, 
  Phone, 
  MapPin, 
  Edit,
  Palette,
  Moon,
  Sun,
  Sparkles,
  LogOut
} from "lucide-react";
import { useState } from "react";

interface NewProfileProps {
  onLogout: () => void;
}

export function NewProfile({ onLogout }: NewProfileProps) {
  const [theme, setTheme] = useState<"light" | "dark">("light");
  const [activeTab, setActiveTab] = useState("overview");

  const achievements = [
    { id: 1, name: "Top Contributor", icon: "🏆", description: "Helped 50+ students", color: "bg-accent/10 border-accent/30" },
    { id: 2, name: "Note Master", icon: "📚", description: "Uploaded 15+ notes", color: "bg-primary/10 border-primary/20" },
    { id: 3, name: "Quick Learner", icon: "⚡", description: "85%+ average", color: "bg-blue-100 border-blue-200" },
    { id: 4, name: "30 Day Streak", icon: "🔥", description: "Active member", color: "bg-secondary/10 border-secondary/20" }
  ];

  const stats = [
    { label: "Notes", value: "15", icon: BookOpen, color: "text-primary" },
    { label: "Doubts", value: "28", icon: MessageSquare, color: "text-purple-600" },
    { label: "Avg. Score", value: "85%", icon: TrendingUp, color: "text-blue-600" },
    { label: "Badges", value: "4", icon: Award, color: "text-accent" }
  ];

  return (
    <div className="space-y-6">
      {/* Profile Header */}
      <Card className="border-border overflow-hidden relative">
        <div className="absolute inset-0 text-primary">
          <IslamicPattern opacity={0.03} />
        </div>
        <div className="absolute top-0 left-0 right-0">
          <GeometricBorder className="text-primary" />
        </div>
        
        <CardContent className="p-6 relative z-10">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6">
            <div className="relative">
              <Avatar className="w-24 h-24 bg-gradient-to-br from-primary to-secondary text-white border-4 border-white shadow-lg">
                <AvatarFallback className="text-2xl">AK</AvatarFallback>
              </Avatar>
              <div className="absolute -bottom-1 -right-1 bg-accent rounded-full p-2">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
            </div>
            
            <div className="flex-1">
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-3">
                <div>
                  <h2 className="mb-1">Ahmed Khan</h2>
                  <p className="text-muted-foreground">B.Tech Computer Science</p>
                  <div className="flex items-center gap-2 mt-2">
                    <Badge className="bg-primary">Semester 6</Badge>
                    <Badge variant="outline">CS-2022-1234</Badge>
                  </div>
                </div>
                <Button variant="outline" size="sm">
                  <Edit className="w-4 h-4 mr-2" />
                  Edit
                </Button>
              </div>
              
              <div className="space-y-2 text-muted-foreground">
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  <span>ahmed.khan@student.amu.ac.in</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  <span>+91 98765 43210</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  <span>Aligarh, Uttar Pradesh</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} className="border-border">
              <CardContent className="p-4 text-center">
                <Icon className={`w-6 h-6 ${stat.color} mx-auto mb-2`} />
                <div className="mb-1">{stat.value}</div>
                <p className="text-muted-foreground">{stat.label}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="w-full grid grid-cols-3">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="achievements">Achievements</TabsTrigger>
          <TabsTrigger value="theme">Customize</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="mt-6">
          <Card className="border-border">
            <CardHeader>
              <CardTitle>Activity Overview</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-muted-foreground">
                  <span>Notes Downloaded</span>
                  <span>42</span>
                </div>
                <div className="flex justify-between text-muted-foreground">
                  <span>Questions Asked</span>
                  <span>28</span>
                </div>
                <div className="flex justify-between text-muted-foreground">
                  <span>Clubs Joined</span>
                  <span>3</span>
                </div>
                <div className="flex justify-between text-muted-foreground">
                  <span>AI Queries</span>
                  <span>156</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="achievements" className="mt-6">
          <Card className="border-border">
            <CardHeader>
              <CardTitle>Achievements & Badges</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {achievements.map((achievement) => (
                  <div 
                    key={achievement.id}
                    className={`flex items-start gap-3 p-4 border ${achievement.color} rounded-lg`}
                  >
                    <div className="text-3xl">{achievement.icon}</div>
                    <div>
                      <h4 className="mb-1">{achievement.name}</h4>
                      <p className="text-muted-foreground">{achievement.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="theme" className="mt-6">
          <ThemeCustomizer />
        </TabsContent>
      </Tabs>

      {/* Logout Button */}
      <Card className="border-destructive/30">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="mb-1">Sign Out</h4>
              <p className="text-muted-foreground">Logout from your account</p>
            </div>
            <Button 
              variant="outline" 
              className="border-destructive text-destructive hover:bg-destructive hover:text-white"
              onClick={onLogout}
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}