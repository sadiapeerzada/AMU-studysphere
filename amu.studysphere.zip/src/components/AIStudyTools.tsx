import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { ScrollArea } from "./ui/scroll-area";
import { GeometricBorder } from "./IslamicPattern";
import { 
  FileText, 
  Languages, 
  CheckCircle, 
  HelpCircle, 
  Copy, 
  Download,
  Sparkles,
  BookOpen,
  X
} from "lucide-react";
import { useState } from "react";

interface AIToolOutput {
  type: "summarize" | "translate" | "proofread" | "quiz";
  content: string;
}

interface AIStudyToolsProps {
  onClose?: () => void;
}

export function AIStudyTools({ onClose }: AIStudyToolsProps) {
  const [inputText, setInputText] = useState("");
  const [output, setOutput] = useState<AIToolOutput | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [targetLanguage, setTargetLanguage] = useState<"urdu" | "hindi">("urdu");

  const tools = [
    {
      id: "summarize",
      label: "Summarizer",
      icon: FileText,
      color: "text-primary",
      bgColor: "bg-primary/10",
      description: "Condense notes into key points"
    },
    {
      id: "translate",
      label: "Translator",
      icon: Languages,
      color: "text-purple-600",
      bgColor: "bg-purple-100",
      description: "Convert to Urdu or Hindi"
    },
    {
      id: "proofread",
      label: "Proofreader",
      icon: CheckCircle,
      color: "text-blue-600",
      bgColor: "bg-blue-100",
      description: "Fix grammar and improve flow"
    },
    {
      id: "quiz",
      label: "Quiz Generator",
      icon: HelpCircle,
      color: "text-accent",
      bgColor: "bg-accent/20",
      description: "Create practice questions"
    }
  ];

  const handleProcess = (toolType: "summarize" | "translate" | "proofread" | "quiz") => {
    if (!inputText.trim()) return;

    setIsProcessing(true);

    setTimeout(() => {
      let content = "";

      switch (toolType) {
        case "summarize":
          content = "✨ **Summary Generated**\n\n**Main Points:**\n\n• Object-Oriented Programming (OOP) is a programming paradigm based on objects and classes\n\n• Key principles include Encapsulation (data hiding), Inheritance (code reuse), Polymorphism (multiple forms), and Abstraction (hiding complexity)\n\n• OOP makes code more modular, reusable, and easier to maintain\n\n• Real-world applications include GUI development, game design, and enterprise software\n\n**Key Concepts:**\n- Classes act as blueprints for objects\n- Objects are instances of classes with specific properties\n- Methods define object behaviors\n\n**Estimated reading time:** 2 minutes (reduced from 10 minutes)";
          break;

        case "translate":
          const lang = targetLanguage === "urdu" ? "Urdu" : "Hindi";
          content = targetLanguage === "urdu"
            ? `🌐 **${lang} Translation**\n\nآبجیکٹ اورینٹڈ پروگرامنگ (او او پی) ایک پروگرامنگ طریقہ ہے جو آبجیکٹس اور کلاسوں پر مبنی ہے۔\n\n**اہم اصول:**\n\n• **انکیپسولیشن (Encapsulation)** - ڈیٹا کو چھپانا\n• **انہیریٹنس (Inheritance)** - کوڈ کو دوبارہ استعمال کرنا\n• **پولی مورفزم (Polymorphism)** - متعدد شکلیں\n• **ایبسٹریکشن (Abstraction)** - پیچیدگی کو چھپانا\n\n**فوائد:**\nاو او پی کوڈ کو زیادہ ماڈیولر، دوبارہ قابل استعمال، اور برقرار رکھنے میں آسان بناتا ہے۔\n\n**اصطلاحات:**\n• Class - کلاس\n• Object - آبجیکٹ\n• Method - طریقہ\n• Property - خاصیت`
            : `🌐 **${lang} Translation**\n\nऑब्जेक्ट ओरिएंटेड प्रोग्रामिंग (ओओपी) एक प्रोग्रामिंग पैराडाइम है जो ऑब्जेक्ट्स और क्लासेस पर आधारित है।\n\n**मुख्य सिद्धांत:**\n\n• **एनकैप्सुलेशन** - डेटा छिपाना\n• **इनहेरिटेंस** - कोड पुन: उपयोग\n• **पॉलीमॉर्फिज्म** - कई रूप\n• **एब्स्ट्रैक्शन** - जटिलता छिपाना\n\n**लाभ:**\nओओपी कोड को अधिक मॉड्यूलर, पुन: प्रयोज्य और बनाए रखने में आसान बनाता है।\n\n**शब्दावली:**\n• Class - वर्ग\n• Object - वस्तु\n• Method - विधि\n• Property - गुण`;
          break;

        case "proofread":
          content = "✓ **Proofread & Enhanced**\n\n**Original Issues Found:**\n• 3 grammar errors corrected\n• 5 punctuation improvements\n• 2 clarity enhancements\n\n**Improved Version:**\n\nObject-Oriented Programming (OOP) is a programming paradigm centered around objects and classes. This approach offers several key advantages for software development.\n\n**Core Principles:**\n\n1. **Encapsulation:** Protects data by restricting direct access and bundling it with related methods.\n\n2. **Inheritance:** Enables code reusability by allowing new classes to inherit properties and methods from existing ones.\n\n3. **Polymorphism:** Permits objects to take multiple forms, making code more flexible and extensible.\n\n4. **Abstraction:** Simplifies complexity by hiding implementation details and exposing only essential features.\n\n**Benefits:**\n- Enhanced code modularity\n- Improved maintainability\n- Greater reusability\n- Better organization\n\n**Clarity Score:** 95/100 ⭐\n**Grammar Score:** 98/100 ⭐\n**Readability:** College Level";
          break;

        case "quiz":
          content = "📝 **Practice Quiz Generated**\n\n**Question 1: Multiple Choice**\nWhat is the main purpose of encapsulation in OOP?\n\nA) To make code run faster\nB) To hide data and restrict direct access ✓\nC) To create multiple objects\nD) To translate code\n\n**Explanation:** Encapsulation protects data integrity by controlling access through methods.\n\n---\n\n**Question 2: Multiple Choice**\nWhich principle allows a child class to inherit properties from a parent class?\n\nA) Polymorphism\nB) Abstraction\nC) Inheritance ✓\nD) Encapsulation\n\n**Explanation:** Inheritance promotes code reuse by establishing parent-child relationships between classes.\n\n---\n\n**Question 3: True/False**\nPolymorphism allows objects to take only one form.\n\nAnswer: False ✗\n\n**Explanation:** Polymorphism means \"many forms\" - it allows objects to behave differently based on context.\n\n---\n\n**Question 4: Short Answer**\nList two benefits of using OOP in software development.\n\n**Sample Answer:**\n1. Better code organization and modularity\n2. Easier maintenance and reusability\n\n---\n\n**Difficulty Level:** Intermediate\n**Estimated Time:** 10 minutes\n**Topics Covered:** Encapsulation, Inheritance, Polymorphism, OOP Benefits";
          break;
      }

      setOutput({ type: toolType, content });
      setIsProcessing(false);
    }, 2000);
  };

  const handleCopy = () => {
    if (output) {
      navigator.clipboard.writeText(output.content);
    }
  };

  const handleDownload = () => {
    if (output) {
      const blob = new Blob([output.content], { type: "text/plain" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `ai-${output.type}-output.txt`;
      a.click();
      URL.revokeObjectURL(url);
    }
  };

  return (
    <>
      {onClose && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      )}
      <Card className={`border-primary/20 bg-gradient-to-br from-primary/5 to-accent/5 relative overflow-hidden ${onClose ? 'fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-full max-w-4xl max-h-[90vh] overflow-y-auto' : ''}`}>
        <div className="absolute top-0 left-0 right-0">
          <GeometricBorder className="text-primary" />
        </div>

        <CardHeader className="pb-4 pt-6">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <div>
                <CardTitle>AI Study Assistant</CardTitle>
                <p className="text-muted-foreground mt-1">Enhance your learning with AI-powered tools</p>
              </div>
            </div>
            {onClose && (
              <Button variant="ghost" size="sm" onClick={onClose} className="h-8 w-8 p-0">
                <X className="w-4 h-4" />
              </Button>
            )}
          </div>
        </CardHeader>

      <CardContent className="space-y-4">
        {/* Tool Buttons */}
        <div className="grid grid-cols-2 gap-3">
          {tools.map((tool) => {
            const Icon = tool.icon;
            return (
              <Button
                key={tool.id}
                variant="outline"
                className={`h-auto flex-col items-start p-3 ${tool.bgColor} border-border hover:shadow-md transition-all group`}
                onClick={() => handleProcess(tool.id as any)}
                disabled={!inputText.trim() || isProcessing}
              >
                <div className="flex items-center gap-2 mb-1 w-full">
                  <Icon className={`w-4 h-4 ${tool.color}`} />
                  <span className="text-sm">{tool.label}</span>
                </div>
                <p className="text-xs text-muted-foreground text-left">{tool.description}</p>
              </Button>
            );
          })}
        </div>

        {/* Language Toggle for Translator */}
        <div className="flex items-center justify-center gap-2">
          <span className="text-muted-foreground">Translate to:</span>
          <Button
            variant={targetLanguage === "urdu" ? "default" : "outline"}
            size="sm"
            onClick={() => setTargetLanguage("urdu")}
            className={targetLanguage === "urdu" ? "bg-primary" : ""}
          >
            Urdu
          </Button>
          <Button
            variant={targetLanguage === "hindi" ? "default" : "outline"}
            size="sm"
            onClick={() => setTargetLanguage("hindi")}
            className={targetLanguage === "hindi" ? "bg-primary" : ""}
          >
            Hindi
          </Button>
        </div>

        {/* Input Area */}
        <div>
          <label className="block mb-2">Paste your text or notes here:</label>
          <Textarea
            placeholder="Enter the content you want to process with AI..."
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            className="min-h-[120px] border-border bg-white"
          />
        </div>

        {/* Processing State */}
        {isProcessing && (
          <Card className="border-border bg-primary/5">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="flex gap-1">
                  <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                  <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                  <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                </div>
                <span className="text-primary">AI is processing your request...</span>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Output Area */}
        {output && !isProcessing && (
          <Card className="border-primary/30 bg-white">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Badge className="bg-primary">AI Generated</Badge>
                  <Badge variant="outline">{output.type}</Badge>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleCopy}
                  >
                    <Copy className="w-4 h-4 mr-1" />
                    Copy
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleDownload}
                  >
                    <Download className="w-4 h-4 mr-1" />
                    Download
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[300px] w-full">
                <div className="whitespace-pre-line leading-relaxed pr-4">
                  {output.content}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        )}
      </CardContent>
    </Card>
    </>
  );
}