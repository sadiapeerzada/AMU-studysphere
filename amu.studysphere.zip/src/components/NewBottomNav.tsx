import { Home, BookOpen, Calendar, Bell, User } from "lucide-react";

interface NewBottomNavProps {
  currentScreen: string;
  onNavigate: (screen: string) => void;
  userRole?: "student" | "professor";
}

export function NewBottomNav({ currentScreen, onNavigate, userRole = "student" }: NewBottomNavProps) {
  const studentNavItems = [
    { id: "dashboard", label: "Home", icon: Home },
    { id: "notes", label: "Notes", icon: BookOpen },
    { id: "timetable", label: "Schedule", icon: Calendar },
    { id: "notices", label: "Notices", icon: Bell },
    { id: "profile", label: "Profile", icon: User }
  ];

  const professorNavItems = [
    { id: "professor-dashboard", label: "Home", icon: Home },
    { id: "notes", label: "Notes", icon: BookOpen },
    { id: "timetable", label: "Schedule", icon: Calendar },
    { id: "notices", label: "Notices", icon: Bell },
    { id: "profile", label: "Profile", icon: User }
  ];

  const navItems = userRole === "professor" ? professorNavItems : studentNavItems;

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-border md:hidden z-50 shadow-lg">
      <div className="flex items-center justify-around py-2 px-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentScreen === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`flex flex-col items-center justify-center py-2 px-3 rounded-lg transition-all ${
                isActive 
                  ? "text-primary bg-primary/10" 
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Icon className={`w-5 h-5 mb-1 ${isActive && 'scale-110'} transition-transform`} />
              <span className="text-xs">{item.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}