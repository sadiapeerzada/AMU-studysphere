import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { Award, BookOpen, MessageSquare, TrendingUp, Mail, Phone, MapPin, Edit, LogOut } from "lucide-react";
import { GeometricBorder } from "./IslamicPattern";

interface ProfileProps {
  onLogout: () => void;
  userRole: "student" | "professor";
}

export function Profile({ onLogout, userRole }: ProfileProps) {
  const achievements = [
    { id: 1, name: "Top Contributor", icon: "🏆", description: "Helped 50+ students" },
    { id: 2, name: "Note Sharer", icon: "📚", description: "Uploaded 10+ notes" },
    { id: 3, name: "Quick Learner", icon: "⚡", description: "85%+ average score" },
    { id: 4, name: "Active Member", icon: "🌟", description: "30 day streak" }
  ];

  const stats = [
    { label: "Notes Uploaded", value: "12", icon: BookOpen, color: "text-primary" },
    { label: "Doubts Solved", value: "24", icon: MessageSquare, color: "text-purple-600" },
    { label: "Avg. Score", value: "85%", icon: TrendingUp, color: "text-blue-600" },
    { label: "Achievements", value: "4", icon: Award, color: "text-accent" }
  ];

  const recentActivity = [
    { action: "Uploaded notes", subject: "Data Structures", time: "2 days ago" },
    { action: "Answered a doubt", subject: "Computer Networks", time: "3 days ago" },
    { action: "Earned badge", subject: "Top Contributor", time: "1 week ago" }
  ];

  return (
    <div className="space-y-6">
      {/* Profile Header */}
      <Card className="border-border">
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6">
            <Avatar className="w-24 h-24 bg-primary text-white">
              <AvatarFallback className="text-2xl">AK</AvatarFallback>
            </Avatar>
            
            <div className="flex-1">
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-3">
                <div>
                  <h2 className="mb-1">Ahmed Khan</h2>
                  <p className="text-muted-foreground">B.Tech Computer Science - Semester 6</p>
                  <Badge className="bg-primary mt-2">Enrollment: CS-2022-1234</Badge>
                </div>
                <Button variant="outline" size="sm">
                  <Edit className="w-4 h-4 mr-2" />
                  Edit Profile
                </Button>
              </div>
              
              <div className="space-y-2 text-muted-foreground">
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  <span>ahmed.khan@student.amu.ac.in</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  <span>+91 98765 43210</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  <span>Aligarh, Uttar Pradesh</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} className="border-border">
              <CardContent className="p-4 text-center">
                <Icon className={`w-6 h-6 ${stat.color} mx-auto mb-2`} />
                <div className="mb-1">{stat.value}</div>
                <p className="text-muted-foreground">{stat.label}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Achievements */}
      <Card className="border-border">
        <CardHeader>
          <CardTitle>Achievements & Badges</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {achievements.map((achievement) => (
              <div 
                key={achievement.id}
                className="flex items-start gap-3 p-4 bg-muted rounded-lg"
              >
                <div className="text-3xl">{achievement.icon}</div>
                <div>
                  <h4 className="mb-1">{achievement.name}</h4>
                  <p className="text-muted-foreground">{achievement.description}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <Card className="border-border">
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentActivity.map((activity, index) => (
              <div key={index} className="flex items-start gap-3 pb-4 last:pb-0 border-b last:border-0">
                <div className="w-2 h-2 bg-primary rounded-full mt-2" />
                <div className="flex-1">
                  <p>{activity.action}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="secondary" className="bg-primary/10 text-primary">
                      {activity.subject}
                    </Badge>
                    <span className="text-muted-foreground">• {activity.time}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Logout Section */}
      <Card className="border-destructive/30">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="mb-1">Sign Out</h4>
              <p className="text-muted-foreground">Logout from your account</p>
            </div>
            <Button 
              variant="outline" 
              className="border-destructive text-destructive hover:bg-destructive hover:text-white"
              onClick={onLogout}
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}