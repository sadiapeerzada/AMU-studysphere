import { useState } from "react";
import { LandingPage } from "./components/LandingPage";
import { EnhancedLoginPage } from "./components/EnhancedLoginPage";
import { Dashboard } from "./components/Dashboard";
import { Sidebar } from "./components/Sidebar";
import { BottomNav } from "./components/BottomNav";
import { LanguageProvider } from "./components/LanguageContext";
import { Toaster } from "./components/ui/sonner";

export default function App() {
  const [showLanding, setShowLanding] = useState(true);
  const [showLogin, setShowLogin] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userRole, setUserRole] = useState<"student" | "professor">("student");
  const [currentView, setCurrentView] = useState("dashboard");
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const handleGetStarted = () => {
    setShowLanding(false);
    setShowLogin(true);
  };

  const handleLogin = (role: "student" | "professor") => {
    setUserRole(role);
    setIsLoggedIn(true);
    setShowLogin(false);
    setCurrentView("dashboard");
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setShowLanding(true);
    setCurrentView("dashboard");
    setUserRole("student");
  };

  if (showLanding) {
    return <LandingPage onGetStarted={handleGetStarted} />;
  }

  if (showLogin) {
    return <EnhancedLoginPage onLogin={handleLogin} />;
  }

  return (
    <LanguageProvider>
      <div className="flex h-screen overflow-hidden bg-background">
        {/* Sidebar for Desktop */}
        <Sidebar 
          currentView={currentView}
          onNavigate={setCurrentView}
          userRole={userRole}
          onLogout={handleLogout}
          isOpen={isSidebarOpen}
          onClose={() => setIsSidebarOpen(false)}
        />

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto">
          <Dashboard 
            currentView={currentView}
            onNavigate={setCurrentView}
            userRole={userRole}
            onLogout={handleLogout}
            onMenuClick={() => setIsSidebarOpen(true)}
          />
        </main>

        {/* Bottom Navigation for Mobile */}
        <BottomNav 
          currentView={currentView}
          onNavigate={setCurrentView}
          userRole={userRole}
        />

        {/* Toast Notifications */}
        <Toaster />
      </div>
    </LanguageProvider>
  );
}
